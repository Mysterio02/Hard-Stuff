//* 'Author:' Madiha Sadaf, UIC, Fall 2022.*//

// file:  bpgame.c


/** #include statements... **/
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "bpgame.h"

/** TYPEDEFS / STRUCTs HERE ***/

struct bpgame {

	int rows;
	int cols; 
  int score;

  BPGame* prev;
	char** arr;
   // YOU DECIDE WHAT TO PUT IN HERE TO CAPTURE THE STATE OF
   //   A "RUN" OF THE GAME.....


};

/*** IMPLEMENTATION OF bp_XXXX FUNCTIONS HERE  ****/

/**
* Function:  bp_create
* Parameters: number of rows and columns
* Description: returns pointer to newly created
*              board with given number of rows
*              and columns.
*
*              Populates board with random balloons.
*
*              If nrows or ncols is out of range, 
*              an error message is printed to stderr
*              and NULL is returned.
*
*/
BPGame * bp_create(int nrows, int ncols) {
    BPGame *b;
   char colors[4] = {Red, Blue, Green, Yellow};

   // out of range rows and columns
   if(nrows < 0 || nrows > MAX_ROWS || ncols < 0 || ncols > MAX_COLS){
      fprintf(stderr,"Invalid size of rows and columns");
      return NULL;
   }

   b = malloc(sizeof(BPGame));
   char** gameBoard = malloc(nrows*sizeof(char*));
   for(int i = 0; i < nrows; i++){
      gameBoard[i] = malloc(ncols*sizeof(char));
   }

   time_t t;
   srand((unsigned) time(&t));

   for(int i = 0; i < nrows; i++){
      for(int j = 0; j < ncols; j++){
         gameBoard[i][j] = colors[rand() % 4];
      }
   }

   b->arr = gameBoard;
   b->rows = nrows;
   b->cols = ncols;
   b->score = 0;
   b->prev = NULL;
   return b;
}
/**
* Function:  bp_create_from_mtx
* Parameters: number of rows and columns and 2D array of char
* Description: returns pointer to newly created
*              board with given number of rows
*              and columns.
*
*              Populates board contents of given 2D matrix (assumes
*	       given dimensions).
*
*	       Error conditions:
*              		If nrows or ncols is out of range, an error message 
*			is printed to stderr and NULL is returned.
*
*			If any element in the matrix is not one of the understood
*			color symbols (from the #define-s at top of this file),
*			an error message is pritnted to stderr and NULL is returned.
*			
*/
BPGame * bp_create_from_mtx(char mtx[][MAX_COLS], int nrows, int ncols){
        // Check bounds
        if (nrows < 0 || nrows > MAX_ROWS || ncols < 0 || ncols > MAX_COLS){
                fprintf(stderr, "nrows or ncols out of bounds!!!");
                return NULL;
        }

        // Create board
        BPGame* curr = malloc(sizeof(BPGame));
        curr->arr = malloc(nrows * sizeof(char*));
       
        for (int i = 0; i < nrows; i++){
            curr->arr[i] = malloc(ncols * sizeof(char));
        }

        // Populate board with balloons from mtx
        for (int i = 0; i < nrows; i++){
            //printf("Row index: %d\n", i);
            for(int j = 0; j < ncols; j++){
                curr->arr[i][j] = mtx[i][j];      
            }
        }
        curr->rows = nrows;
        curr->cols = ncols;
        curr->score = 0;
        curr->prev = NULL;
        return curr;
}

/**
* Function:  bp_destroy
* Description:  deallocates all dynamically allocated 
*  		memory associated with the board.
*		
*		Comment:  this might start out as
*		a one-liner.  
*
*/
void bp_destroy(BPGame * b){
        for (int i = 0; i < b->rows; i++){
                free(b->arr[i]);
        }
        free(b->arr);
        free(b);
}

/**
* Function:  bp_display
* Description:  pretty-prints the current board.
*
*		uses '|', '+' and '-' to "draw" the boundaries
*               of the board.
*
*		For full credit rows and columns are labeled with
* 		their indices.  Column indices displayed "vertically"
*
*		Examples:
*
*  This board is full of balloons (like at the beginning of a game).
* 
*       +-----------------------+
*		  0 | + + + = + ^ ^ o + = = |
*		  1 | ^ = = o + o + + + ^ = |
*		  2 | ^ + ^ o + o + = = = = |
*		  3 | = ^ o o = o + + + = = |
*		    +-----------------------+
* 		    0 0 0 0 0 0 0 0 0 0 1
*		      0 1 2 3 4 5 6 7 8 9 0
*
*
*  This board has some empty slots represented by  '.'
*       +-----------------------+
*		  0 | + + + = + ^ ^ o + = = |
*		  1 | ^ = o o + o + + + ^ = |
*		  2 | ^ + . o + . + = . . = |
*		  3 | . . . o . . + + . . = |
*		    +-----------------------+
* 		    0 0 0 0 0 0 0 0 0 0 1
*		      0 1 2 3 4 5 6 7 8 9 0
*
*
*  Here is the same board using a space ' ' to 
*  represent an empty slot.
*
*       +-----------------------+
*		  0 | + + + = + ^ ^ o + = = |
*		  1 | ^ = o o + o + + + ^ = |
*		  2 | ^ +   o +   + =     = |
*		  3 |       o     + +     = |
*		    +-----------------------+
* 		    0 0 0 0 0 0 0 0 0 0 1
*		      0 1 2 3 4 5 6 7 8 9 0
*
*/

void bp_display_STD(BPGame *b) {
    for (int i = 0; i <b->rows; i++) {
        for (int j = 0; j <b->cols; j++) {
            if(b->arr[i][j] == ' ')
                printf(".");
            else
                printf("%c", b->arr[i][j]);
        }
        printf("\n");
    }
}

void bp_display(BPGame * b){
        // Print top border
        printf("\n  +");
        int top_row_edge = 2 * b->cols + 1;
        for (int i = 0; i < top_row_edge; i++){
                printf("-");
        }
        printf("+\n");

        for(int i = 0; i < b->rows; i++) {
            if(i < 10) 
                printf("%d |",i);
            else
                printf("%d|",i);
            for (int j = 0; j < b->cols; j++){
                printf(" %c", b->arr[i][j]);
            }
            printf(" |\n");
        }

        // Print bottom border
        printf("  +");
        for (int i = 0; i < top_row_edge; i++){
                printf("-");
        }
        printf("+\n    ");
        for(int i = 0; i < b->cols; i++) {
            if(i < 10) 
                printf("0 ");
            else
                printf("%d ",(i/10));
        }
        printf("\n    ");
        for(int i = 0; i < b->cols; i++) {
            printf("%d ",(i%10));
        }
        printf("\n");
}



/**
* Function:  bp_pop
* Description:  (attempts to) "pop" the balloon at (r,c) (if any)
*               and its associated "color cluster"
*
*               Cluster must be of AT LEASE SIZE 2 (a balloon that
*   		        is its own cluster will not be popped).
*
* Returns:  number of balloons popped (which may be zero).
*
* Side effects:  
*		locations of popped balloons become None (as in the "color"
*			None in the #define at the top of this file).
*
*		adds n*(n-1) to score if n balloons were popped.
*
* Notes:  does not require that the board be "compact".  But presumably, 
*	most client applicationw would only call on a compact board.
*
*/
void helper(BPGame* b){
  BPGame *bNew = malloc(sizeof(BPGame));
    char** arr2 = malloc(b->rows * sizeof(char*));
    for (int i = 0; i < b->rows; i++){
        arr2[i] = malloc(b->cols * sizeof(char));
    }

    for (int i = 0; i < b->rows; i++){
        for(int j = 0; j < b->cols; j++){
            arr2[i][j] = b->arr[i][j];
        }
    }
    
    bNew->arr = arr2;
    bNew->rows = b->rows;
    bNew->cols = b->cols;
    bNew->score = b->score;
    bNew->prev = b->prev;
    b->prev = bNew;
}
int can_pop_rc(BPGame* b, int r, int c, char color){
    if( (r < 0) || (c < 0) || (r >= b->rows) || (c >= b->cols) || (b->arr[r][c] != color)){

        return 0;

    }

    int counter = 0;

    if(b->arr[r][c] == color){

        counter++;

        b->arr[r][c] = None;

        

    }

    

    counter += can_pop_rc(b,r+1, c, color);

    counter += can_pop_rc(b,r-1, c, color);

    counter += can_pop_rc(b,r, c+1, color);

    counter += can_pop_rc(b,r, c-1, color);



    return counter;}

/**
* Function:  bp_pop
* Description:  (attempts to) "pop" the balloon at (r,c) (if any)
*               and its associated "color cluster"
*
*               Cluster must be of AT LEASE SIZE 2 (a balloon that
*                   is its own cluster will not be popped).
*
* Returns:  number of balloons popped (which may be zero).
*
* Side effects:  
*        locations of popped balloons become None (as in the "color"
*            None in the #define at the top of this file).
*
*        adds n*(n-1) to score if n balloons were popped.
*
* Notes:  does not require that the board be "compact".  But presumably, 
*    most client applicationw would only call on a compact board.
*
*/
int bp_pop(BPGame * b, int r, int c)
{
    int hasNeighbors = 0;
    if(b->arr[r][c] == None) {
        return 0;
    }
   char color = b->arr[r][c];
    helper(b);
    
    hasNeighbors += can_pop_rc(b,r,c, color);
    if(hasNeighbors <= 0) {
        bp_undo(b);
    }
    b->score += hasNeighbors*(hasNeighbors-1);
    return hasNeighbors;
}



/**
* Function:  bp_is_compact
* Description:  determines if all balloons are as "high" as possible.
*               Returns 1 if this is the case
*               Returns 0 otherwise.
*
*               Note:  a balloon is as high as possible if and only
*     		if all slots in its column ABOVE it are also balloons
*		(non-empty)
*
*/
int bp_is_compact(BPGame * b){
    for (int j = 0; j < b->cols; j++) {
        for (int i = 1; i < b->rows; i++){
            if (b->arr[i][j] != None && b->arr[i-1][j] == None) {
                return 0;
            }
        }
    }
    return 1;
}

/**
* Function:  bp_float_one_step
* Description:  moves all balloons that that are NOT AS HIGH AS POSSIBLE
*               up one spot.  
*
*   Example:
*
*		before
*
*       +-----------------------+
*		  0 | + + + = + ^     + = = |
*		  1 | ^       + o + +   ^ = |
*		  2 | ^ +   o +   + =     = |
*		  3 |       o     + + =   = |
*		    +-----------------------+
* 		    0 0 0 0 0 0 0 0 0 0 1
*		      0 1 2 3 4 5 6 7 8 9 0
*
*		after
*
*       +-----------------------+
*		  0 | + + + = + ^ + + + = = |
*		  1 | ^ +   o + o + =   ^ = |
*		  2 | ^     o +   + + =   = |
*		  3 |                     = |
*		    +-----------------------+
* 		    0 0 0 0 0 0 0 0 0 0 1
*		      0 1 2 3 4 5 6 7 8 9 0
*
*
* Note:  think animation by repeating this until it
*   is compact (perhaps displaying each intermediate
*   configuration).
*/
void swap_places(BPGame * b, int row, int col){
    b->arr[row][col] = b->arr[row+1][col];
    b->arr[row+1][col] = None;
}

void bp_float_one_step(BPGame * b){  
    for (int i = 0; i < b->rows-1; i++){
        for (int j = 0; j < b->cols; j++){
            if (b->arr[i][j] == None && b->arr[i+1][j] != None){swap_places(b, i, j);}
        }
    }
}

/**
* Function:  bp_score
* Description:  returns the current score 
*
*/
int bp_score(BPGame * b)
{
        return b->score;
}


/**
* Function:   bp_get_balloon
* Description:  returns color of balloon at given location as a char.
*		if (r,c) is out of range, -1 is returned.
*
*/
int bp_get_balloon(BPGame * b, int r, int c)
{
  if (r < 0 || r > MAX_ROWS || c < 0 || c > MAX_COLS){
                return -1;
        }
        return b->arr[r][c];
}


/**
* Function:   bp_can_pop
* Description:  returns 1 if the player can pop some balloons;
*		        0 otherwise.
*
*		If the board is empty, of course nothing can
*			be popped.
*		If there are no adjacent balloons of the same
*		color, there also are no moves.
*	
* Notes:  probable usage is to determine when game is over.
*/
int bp_can_pop(BPGame * b) {
    int count = 0;
    int tmp = 0;
    for (int r = 0; r < b -> rows; r++) {
        for (int c = 0; c < b->cols; c++) {
            if (b->arr[r][c] != None) {
                count++;
                break;
            }
        }
    }
    // checks there is at least two balloons being popped
    if (count < 1) {
        return 0;
    }

    char top = None;
    char bottom = None;
    char left = None;
    char right = None;
    char color = None;
    for (int r = 0; r < b -> rows; r++) {
        for (int c = 0; c < b -> cols; c++) {
            // there is a balloon
            if (b -> arr[r][c] != None) {
                color = b -> arr[r][c];
            }
            // next four if statements making sure will not check out of bounds
            if (r != 0) {
                top = b -> arr[r - 1][c];
            }
            if (r != ((b->rows) - 1)) {
                bottom = b -> arr[r + 1][c];
            }
            if (c != 0) {
                left = b -> arr[r][c - 1];
            }
            if (c != ((b->cols) - 1)) {
                right = b -> arr[r][c + 1];
            }
            // some match popping was found
            if (color == top || color == bottom || color == right || color == left) {
                tmp = 1;
            }
        }
        if (tmp == 1) {
            break;
        }
    }
    return tmp;
}

/**
* Function:  bp_undo
* Description:  "undoes" most recent successful pop (if any), 
*		restoring the board to the exact state it was 
*		in immediately prior to that pop.
*
*               Also restores score to corresponding previous value.
*
*               Returns 1 if successful; 0 otherwise (i.e., when in the initial state --
*		no moves have been made to be undone).
*
*		NOTE:  bp_undo can be called repeatedly to back up all the way to the beginning
*		of the game.
*
*/
int bp_undo(BPGame * b){
  // remember previous move
    if(b->prev == NULL) {
        return 0;
    }
    BPGame* prevState = b->prev;
    for(int i = 0; i < b->rows; i++) {
        for(int j = 0; j < b->cols; j++) {
            b->arr[i][j] = b->prev->arr[i][j];
        }
    }
    b->rows = b->prev->rows;
    b->cols = b->prev->cols;
    b->score = b->prev->score;
    b->prev = b->prev->prev;
    bp_destroy(prevState);
    prevState = NULL;
    return 1;
}
