#include <stdio.h>
#include<stdlib.h>

void clause(int i)
{
    if(i < 0)
    {
        printf("INVALID INPUT");
        exit(1);
    }
}

int high(int A, int B, int C, int D)
{
    if(A >= B && A >= C && A >= D)
    return A;

    else if(B >= A && B >= C && B >= D)
    return B;

    if(C >= A && C >= B && C >= D)
    return C;
    else
    return D;
}

int main()
{
    int A,B,C,D, highest;

    printf("A: ");
    scanf("%i", &A);
    clause(A);
    printf("B: ");
    scanf("%i", &B);
    clause(B);

    printf("C: ");
    scanf("%i", &C);
    clause(C);

    printf("D: ");
    scanf("%i", &D);
    clause(D);

    highest = high(A,B,C,D);
    printf("\n\n");

    for(int i = highest; i > 0; i--)

    {
        printf(" ");

        if(A >= i)
        printf("X ");
        else
        printf(" ");

        if(B >= i)
        printf("X ");
        else
        printf(" ");

        if(C >= i)
        printf("X ");
        else
        printf(" ");

        if(D >= i)
        printf("X ");
        else
        printf(" ");

        printf("\n");

    }

    printf("-------\n A B C D\n");

}