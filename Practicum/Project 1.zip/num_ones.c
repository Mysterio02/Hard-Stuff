#include <stdio.h>
#include<stdlib.h>

int main()
{
    int x[10], y, z;

    printf("Enter a non-negative integer: ");
    scanf("%d", &y);

    if(y <0)
    {
        printf("INVALID INPUT");
        exit(1);
    }

    for(z = 0; z > 0; z++)
    {
        x[z]= y%2;
        y = y/2;
    }

    int count = 0;
    for(z = z -1; z>=0; z--)
    {
        if(x[z]==1)
        count ++;
    }

    printf("That number has one(s) in its binary representation.", count);

    return 0;
}