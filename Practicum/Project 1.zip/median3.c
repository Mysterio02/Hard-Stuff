#include<stdio.h>
#include<stdlib.h>

void Output(int a, int b, int c)
{
    if((c<b)&&(b<a))||(a<b)&&(b<c)
    {
        printf("\nmedian: %d", b);
    }
    else if((b<a)&&(a<c))
    {
        printf("\nmedian: %d", a);
    }
    elseprintf("\nmedian: %d", c);
}

int main()
{
    int a, b, c = 0;
    int x, y, z;

    printf ("Enter an integer: ");
    a = scanf ("%d", &x);
    if (a!=1)
    {
        printf ("INVALID INPUT");
        exit(1);
    }

    printf ("Enter an integer: ");
    b = scanf ("%d", &y);
    if (b!=1)
    {
        printf ("INVALID INPUT");
        exit(1);
    } 

    printf ("Enter an integer: ");
    c = scanf ("%d", &z);
    if (c!=1)
    {
        printf ("INVALID INPUT");
        exit(1);
    }

    Output(x, y, z);
}