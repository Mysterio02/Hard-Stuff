#include<stdio.h>
#include<stdlib.h>
#include<time.h>

int main()
{
    int A, B, distanceA, distanceB;
    int a = 5, b = 5;
    int GoldA = 0, GoldB = 0;
    char userInput = 0;
    int iterations = 0;

    printf("Your position (%i,%i)\n", a, b);

    do
    {
    srand(time(0));
    GoldA = rand()%10;
    GoldB = rand()%10;
    }
    while(a == GoldA && b == GoldB);

    int i = 0;
    distanceA = GoldA - a;
    distanceB = GoldB - b;
    while(i < 1)
    {
        printf("Direction: ");
        scanf(" %c", &userInput);
        if(userInput == 'q')
        exit(1);
        {
            if(userInput == 'n')
            {
                a++;
            }
            else if(userInput == 's')
            {
                a--;
            }
            if(userInput == 'e')
            {
                b++;
            }
            if(userInput == 'w')
            {
                b--;
            }

            else if(userInput != 'n' || userInput !='s' || userInput != 'e' || userInput != 'w')
            printf("INVALID INPUT, TRY AGAIN\n");}
    }

        { 
            if(a == -1)
        {
            printf("Ouch!\n");
            a++;
        }
        if(a == 11)
        {
            printf("Ouch!\n");
            a--;
        }
        if(b == -1)
        {
            printf("Ouch!\n");
            b++;
        }
        if(b == 11)
        {
            printf("Ouch!\n");
            b--;
        }
        }

        if(userInput == 'n' || userInput =='s' || userInput == 'e' || userInput == 'w')
        {
            A = GoldA -a;
            B = GoldB - b;
            iterations++;
        }

        if(a == GoldA && b == GoldB)
        {
            printf(" HOORAY!\n\n Total Moves: %i \n Goodbye!", iterations);
            exit(1);
        }

        if(a != 10 && a!= 0)
        {
            if(userInput == 'n' || userInput == 's')
            {
                if(abs(A)> abs (distanceA))
                printf(" GETTING COLDER!\n");
                else
                printf(" GETTING WARMER\n");
            }
        }
        if(b != 0 && b!=10)
        {
            if(userInput == 'e' || userInput == 'w')
            {
                if(abs(B)>abs(distanceB))
                printf(" GETTING COLDER!\n");
                else
                printf(" GETTING WARMER!\n");
            }
        }

        printf("Current coordinates: (%i,%i)", a, b);
        distanceA = A;
        distanceB = B;
    }