#include <stdio.h>
#include <stdlib.h>
#include "sq.h"

/*
* file:  sq.h
* description:  specifies the interface for
*  	the "service queue" ADT.
*/


/**
* SQ is an "incompletely specified type."  
*
* The definition of struct service_queue must
* be (hidden) in an implementation .c file.
*
* This has two consequences:
*
*	- Different implementations are free to
*	 	specify the structure as suits
*		their approach.
*
*	- "client" code can only have pointers
*		to service_queue structures (type
*		SQ *).  More importantly, it cannot
*		de-reference the pointers.  This
*		lets us enforce one of the principles
*		of ADTs:  the only operations that
*		can be performed on a service queue
*		are those specified in the interface
*		-- i.e., the functions specified below.
*/

// node struct
typedef struct node {
  struct node* next;
  struct node* prev;
  int value;

  
  int ifInQueue;

} NODE;

// list struct
struct list_struct {
  NODE* front;
  NODE* back;

  int size;
} typedef LIST;

// service queue struct
struct service_queue {
  LIST* queue;
  LIST* buzzer_bucket; 

 
  NODE** serviceQueueMap;

  
  int NodesInQueue;

  int mapLength;

  int totalbuzzers;

} typedef SQ;

// Creates empty list
LIST* lst_create() {
  LIST* list = malloc(sizeof(LIST));
  list->front = NULL;
  list->back = NULL;
  return list;
}

/**
* Function: sq_create()
* Description: creates and intializes an empty service queue.
* 	It is returned as an SQ pointer.
* 
* RUNTIME REQUIREMENT: O(1)
*/
SQ* sq_create() {
  SQ* q = malloc(sizeof(SQ));

  q->queue = lst_create();

  q->buzzer_bucket = lst_create();

  q->serviceQueueMap = malloc(4 * sizeof(NODE*));

  q->mapLength = 4;
  q->totalbuzzers = 0;
  q->NodesInQueue = -1;

  return q;
}

/*
 * resize: doubles the size
 * of the map when needed.
 */
void resize(SQ* q) {
  // allocate a new array double
  // the size of the current array
  NODE** newSize = malloc(q->mapLength * 2 * sizeof(NODE*));

  
  for (int i = 0; i < q->mapLength; i++) {
    newSize[i] = q->serviceQueueMap[i];
  }

 
  q->mapLength *= 2;

  free(q->serviceQueueMap);


  q->serviceQueueMap = newSize;
}

// links a node to a list:

void linkNodeToList(SQ* q, NODE* node, int type) {
  LIST* list = q->queue;

  if (type == 1) {
    
    list = q->buzzer_bucket;
  } else {
    
    list = q->queue;
  }

  if (list->front == NULL) {
    list->front = node;
    list->back = node;
    return;
  }

  node->prev = list->back;

  list->back->next = node;

  node->next = NULL;

  list->back = node;
}

/*
 * allocates memory for a node;
 * links the new node to the queue and
 * adds it to the queue;
 * returns the new node.
 */
NODE* addNode(SQ* q, int type) {
  NODE* newNode = malloc(sizeof(NODE));
  newNode->next = NULL;
  newNode->prev = NULL;
  newNode->ifInQueue = 0;
  newNode->value = 0;

  linkNodeToList(q, newNode, type);

  return newNode;
}

/**
* Function: sq_free()
* Description:  deallocates all memory assciated
*   with service queue given by q.
*
* RUNTIME REQUIREMENT:  O(N_b) where N_b is the number of buzzer 
*	IDs that have been used during the lifetime of the
*	service queue; in general, at any particular instant
*	the actual queue length may be less than N_b.
*
*	[See discussion of "re-using buzzers" below]
*
*/

void sq_free(SQ* q) {
  
  for (int i = 0; i < q->totalbuzzers; i++) {
    free(q->serviceQueueMap[i]);
  }

  free(q->serviceQueueMap);

  free(q->queue);

  free(q->buzzer_bucket);

  free(q);
}

/**
* Function: sq_display()
* Description:  prints the buzzer IDs currently
*    in the queue from front to back.
*
* RUNTIME REQUIREMENT:  O(N)  (where N is the current queue
*		length).
*/
void sq_display(SQ* q) {
  NODE* current = q->queue->front;

  printf("\n    ");

  printf("[ ");
  while (current != NULL) {
    printf("%d ", current->value);
    if (current->next != NULL) {
      current = current->next;
    } else {
      current = NULL;
    }
  }
  printf("]\n");

  printf("\n");
}

// returns the length of the list
int lst_length(LIST* l) { return l->size; }

/**
* Function: sq_length()
* Description:  returns the current number of
*    entries in the queue.
*
* RUNTIME REQUIREMENT:  O(1)
*/

int sq_length(SQ* q) { return q->NodesInQueue + 1; }

// checks if the list if empty
int lst_is_empty(LIST* l) {
  if (l->front == NULL) {
    return 1;
  }
  return 0;
}

/**
* Function: sq_give_buzzer()
* Description:  This is the "enqueue" operation.  For us
*    a "buzzer" is represented by an integer (starting
*    from zero).  The function selects an available buzzer 
*    and places a new entry at the end of the service queue 
*    with the selected buzer-ID. 
*    This buzzer ID is returned.
*    The assigned buzzer-ID is a non-negative integer 
*    with the following properties:
*
*       (1) the buzzer (really it's ID) is not currently 
*         taken -- i.e., not in the queue.  (It
*         may have been in the queue at some previous
*         time -- i.e., buzzer can be re-used).
*	  This makes sense:  you can't give the same
*	  buzzer to two people!
*
*       (2) If there are buzzers that can be re-used, one
*         of those buzzers is used.  A re-usable buzzer is 
*	  a buzzer that _was_ in the queue at some previous
*	  time, but currently is not.
*
*       (3) if there are no previously-used buzzers, the smallest 
*         possible buzzer-ID is used (retrieved from inventory).  
*	  Properties in this situation (where N is the current
*	  queue length):
*
*		- The largest buzzer-ID used so far is N-1
*
*		- All buzzer-IDs in {0..N-1} are in the queue
*			(in some order).
*
*		- The next buzzer-ID (from the basement) is N.
*
*    In other words, you can always get more buzzers (from
*    the basement or something), but you don't fetch an
*    additional buzzer unless you have to.
*    you don't order new buzzers 
*
* Comments/Reminders:
*
*	Rule (3) implies that when we start from an empty queue,
*	the first buzzer-ID will be 0 (zero).
*
*	Rule (2) does NOT require that the _minimum_ reuseable 
*	buzzer-ID be used.  If there are multiple reuseable buzzers, 
*	any one of them will do.
*	
*	Note the following property:  if there are no re-useable 
*	buzzers, the queue contains all buzzers in {0..N-1} where
*       N is the current queue length (of course, the buzzer IDs 
*	may be in any order.)
*
* RUNTIME REQUIREMENT:  O(1)  ON AVERAGE or "AMORTIZED"  
		In other words, if there have been M calls to 
*		sq_give_buzzer, the total time taken for those 
*		M calls is O(M).
*
*		An individual call may therefore not be O(1) so long
*		as when taken as a whole they average constant time.
*
*		(Hopefully this reminds you of an idea we employed in
*		the array-based implementation of the stack ADT).
*/
int sq_give_buzzer(SQ* q) {
  
  int buzzerValue = 0;

  
  if (q->buzzer_bucket->front != NULL) {
    NODE* buzzer = q->buzzer_bucket->back;

  
    buzzer->ifInQueue = 1;

    q->buzzer_bucket->back = q->buzzer_bucket->back->prev;

    // store the buzzer value
    buzzerValue = buzzer->value;

    // add the buzzer to the queue
    linkNodeToList(q, buzzer, 0);

  
    if (q->buzzer_bucket->front == buzzer) {
      q->buzzer_bucket->front = NULL;
    }
  } else {
    /*
     * Check to see if the map 
     * needs to be resized.
     */
    if (q->NodesInQueue + 1 >= q->mapLength) {
      resize(q);
    }

    
    NODE* node = addNode(q, 0);

    node->value = q->totalbuzzers;

 
    node->ifInQueue = 1;

  
    q->serviceQueueMap[node->value] = node;

    buzzerValue = q->totalbuzzers++;
  }

  // update the number of nodes used
  q->NodesInQueue++;

  return buzzerValue;
}

/**
* function: sq_seat()
* description:  if the queue is non-empty, it removes the first 
*	 entry from (front of queue) and returns the 
*	 buzzer ID.
*	 Note that the returned buzzer can now be re-used.
*
*	 If the queue is empty (nobody to seat), -1 is returned to
*	 indicate this fact.
*
* RUNTIME REQUIREMENT:  O(1)
*/
int sq_seat(SQ* q) {
  if (lst_is_empty(q->queue)) {
    return -1;
  }

  NODE* buzzer = q->queue->front;

  buzzer->ifInQueue = 0;

  if (buzzer->prev != NULL) {
    buzzer->prev->next = NULL;
  } else if (buzzer->next != NULL) {
    buzzer->next->prev = NULL;
  }

  q->queue->front = q->queue->front->next;

  // link node to buzzer bucket
  linkNodeToList(q, buzzer, 1);

  // update amount of buzzers in use
  q->NodesInQueue--;

  return q->buzzer_bucket->back->value;
}

/**
* function: sq_kick_out()
*
* description:  Some times buzzer holders cause trouble and
*		a bouncer needs to take back their buzzer and
*		tell them to get lost.
*
*		Specifially:
*
*		If the buzzer given by the 2nd parameter is 
*		in the queue, the buzzer is removed (and the
*		buzzer can now be re-used) and 1 (one) is
*		returned (indicating success).
*
*		If the buzzer isn't actually currently in the
*		queue, the queue is unchanged and 0 is returned
*		(indicating failure).
*
* RUNTIME REQUIREMENT:  O(1)
*/
int sq_kick_out(SQ* q, int buzzer) {
  
  if (q->serviceQueueMap[buzzer]->ifInQueue == 0 ||
      q->totalbuzzers <= buzzer) {
    return 0;
  }

  NODE* cur = q->serviceQueueMap[buzzer];

  if (q->serviceQueueMap[buzzer]->next != NULL ||
      q->serviceQueueMap[buzzer]->prev != NULL) {
    if (q->serviceQueueMap[buzzer]->next == NULL) {
      
      q->queue->back = q->queue->back->prev;

      q->queue->back->next = NULL;
    } else if (q->serviceQueueMap[buzzer]->prev == NULL) {
     
      q->queue->front = q->queue->front->next;

      q->queue->front->prev = NULL;
    } else {
     

      q->serviceQueueMap[buzzer]->next->prev = q->serviceQueueMap[buzzer]->prev;

      q->serviceQueueMap[buzzer]->prev->next = q->serviceQueueMap[buzzer]->next;
    }

  } else if (q->serviceQueueMap[buzzer]->next == NULL &&
             q->serviceQueueMap[buzzer]->prev == NULL) {
    
    q->queue->back = NULL;
    q->queue->front = NULL;
  }

  
  q->serviceQueueMap[buzzer]->ifInQueue = 0;

  // link current node to list
  linkNodeToList(q, q->serviceQueueMap[buzzer], 1);

 
  q->NodesInQueue--;

  return 1;
}

/**
* function:  sq_take_bribe()
* description:  some people just don't think the rules of everyday
*		life apply to them!  They always want to be at
*		the front of the line and don't mind bribing
*		a bouncer to get there.
*
*	        In terms of the function:
*
*		  - if the given buzzer is in the queue, it is 
*		    moved from its current position to the front
*		    of the queue.  1 is returned indicating success
*		    of the operation.
*		  - if the buzzer is not in the queue, the queue 
*		    is unchanged and 0 is returned (operation failed).
*
* RUNTIME REQUIREMENT:  O(1)
*/
int sq_take_bribe(SQ* q, int buzzer) {
  if (q->totalbuzzers <= buzzer ||
      q->serviceQueueMap[buzzer]->ifInQueue == 0 || q->NodesInQueue == -1) {
    return 0;
  }

  if (q->queue->front == q->serviceQueueMap[buzzer]) {
    return 1;
  }

  NODE* current = q->serviceQueueMap[buzzer];

  if (q->serviceQueueMap[buzzer]->next == NULL) {
    
    current->prev->next = NULL;

    q->queue->back = current->prev;

    q->queue->front->prev = current;

    current->next = q->queue->front;

    q->queue->front = current;

    current->prev = NULL;
  } else {
    
    current->prev->next = current->next;

   
    current->next->prev = current->prev;

    
    current->next = q->queue->front;

   
    q->queue->front->prev = current;

    
    q->queue->front = current;
  }

  return 1;
}