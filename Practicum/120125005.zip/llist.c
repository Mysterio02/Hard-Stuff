#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include "list.h"



typedef struct node {
    ElemType val;
    struct node *next;
} NODE;


struct list_struct {
    NODE *front;
    NODE *back;
    int size;
};


/*
* returns pointer to newly created empty list
*/
LIST *lst_create() {
        LIST *l = malloc(sizeof(LIST));

        l->front = NULL;
        l->back = NULL;
        l->size = 0;
        return l;
}

void lst_free(LIST *l) {
        NODE *p = l->front;
        NODE *pnext;

        while(p != NULL) {
                pnext = p->next;   // keeps us from de-referencing a freed ptr
                free(p);
                p = pnext;
        }
        // now free the LIST 
        free(l);
}

void lst_print(LIST *l) {
NODE *p = l->front;

  printf("[");
  while(p != NULL) {
    printf(FORMAT, p->val);
    p = p->next;
  }
  printf("]\n");
}



int lst_are_equal(LIST *lst1, LIST *lst2) {
        NODE *pLst1 = lst1->front;
        NODE *pLst2 = lst2->front; 
        while(pLst1 != NULL || pLst2 != NULL){
                if(pLst1->val != pLst2->val){
                        return 0;
                }
                else{
                        pLst1 = pLst1->next;
                        pLst2 = pLst2->next;
                }
        }

        return 1;  // placeholder

}



//RECURSIVE HELPER FUNCTION
void recurse(NODE *p){
        if(p == NULL){
                return;
        }
        else{
                recurse(p->next);
                printf(FORMAT, p->val);
        }
        
}
void lst_print_rev(LIST *l) {
        printf("[");
        recurse(l->front);
        printf("]\n");
}

void lst_push_front(LIST *l, ElemType val) {
        NODE *p = malloc(sizeof(NODE));

        p->val = val;
        p->next = l->front;
  
        l->front = p;
        if(l->back == NULL)   // was empty, now one elem
                l->back = p;
        l->size++;//increment size after push
}

void lst_push_back(LIST *l, ElemType val) {
        NODE *p;

        if(l->back == NULL)   // list empty - same as push_front
                lst_push_front(l, val);
        else {  // at least one element before push
                p = malloc(sizeof(NODE));
                p->val = val;
                p->next = NULL;
                l->back->next = p;

                l->back = p;
                l->size++;//increment size after push        
  }
}


int lst_length(LIST *l) {
        /* LINEAR RUNTIME O(N)
        NODE *p = l->front;
        int n=0;

        while(p != NULL) {
                n++;
                p = p->next;
        }
        return n;*/

        //CONSTANT RUNTIME O(1)
        return l->size;
}

int lst_is_empty(LIST *l) {
  return l->front == NULL;
}



int lst_count(LIST *l, ElemType x) {
        NODE *p = l->front;
        int counter = 0;
        while(p != NULL){
                if(p->val == x){
                        counter++;
                }
                p = p->next;
        }
  return counter; 
}


/* These are "sanity checker" functions that check to see
*     list invariants hold or not.
*/
int lst_sanity1(LIST *l) {
  if(l->front == NULL && l->back != NULL){
        fprintf(stderr, "lst_sanity1 error:  front NULL but back non-NULL\n");
        return 0;
  }
  if(l->back == NULL && l->front != NULL){
        fprintf(stderr, "lst_sanity1 error:  back NULL but front non-NULL\n");
        return 0;
  }
  return 1;
}

int lst_sanity2(LIST *l) {
  if(l->back != NULL && l->back->next != NULL) {
        fprintf(stderr, "lst_sanity2 error:  back elem has a non-NULL next?\n");
        return 0;
  }
  return 1;
}


static NODE * find_back(NODE *p) {

  if(p ==  NULL)
        return NULL;

  while(p->next != NULL) {
        p = p->next;
  }
  return p;
}


int lst_sanity3(LIST *l) {
NODE *real_back;

  real_back = find_back(l->front);

  return (real_back == l->back);
}



ElemType lst_pop_front(LIST *l) {
ElemType ret;
NODE *p;
 

  if(lst_is_empty(l))
        return DEFAULT;   // no-op

  ret = l->front->val;
  
  if(l->front == l->back) {  // one element
        free(l->front);
        l->front = NULL;
        l->back = NULL;
        l->size = 0;
  }
  else {
        p = l->front;  // don't lose node being deleted
        l->front = l->front->next;// hop over
        l->size--;
        free(p);
  }
  return ret;
}

     
  



ElemType lst_pop_back(LIST *l) {
        int elem;
        if(lst_is_empty(l)){
                return DEFAULT;
        }
        if( l->front == l->back ){
                elem = l->front->val;
                free(l->front);
                l->front = NULL;
                l->back = NULL;
                l->size = 0;
                return elem;
        }
        else{   
                NODE *pPopped = malloc(sizeof(NODE)); 
                pPopped = l->back;
                NODE *p = l->front;
                //gets second to last element
                while(p->next->next != NULL){
                        p = p->next;
                }
                //stores element to be popped   
                elem = pPopped->val;
                //second to last element becomes last element 
                p->next = NULL;
                l->back = p;
                l->size--;//decrease size
                //frees the popped element
                free(pPopped);
                //returns popped element
                return elem;

        }

} 



//HELPER TO REVERSE LINKS

void recurse2(NODE* prev, NODE *curr){
        
        if(curr == NULL){
                return;
        }
        else{
                recurse2(curr, curr->next);
                curr->next = prev;//current node->next now points to the previous node, reversing the link
        }

}



void lst_reverse(LIST *l) {
        if(l->front != NULL){
                NODE *p = l->front;//temp variable to hold front of list
                recurse2(l->front, l->front->next);//reverses links
                l->front = l->back;//front of the list is now what used to be the back (after links have been reversed)
                l->back = p;//back of the list now points to what was previously the front
                l->back->next = NULL;//back of the list points to NULL    
        }

}



int lst_remove_first(LIST *l, ElemType x) {
        NODE *p;
        NODE *tmp;

        if(l->front == NULL) return 0;
        if(l->front->val == x) {
                lst_pop_front(l);
                return 1;
        }
  // lst non-empty; no match on 1st elem
        p = l->front;

        while(p->next != NULL) {
                if(x == p->next->val) {
                        tmp = p->next;
                        p->next = tmp->next;
                        if(tmp == l->back) 
                                l->back = p;
                        free(tmp);
                        l->size--;
                        return 1;
                }
                p = p->next;
        }
        return 0;
}



int lst_remove_all_slow(LIST *l, ElemType x) {
  int n=0;
  while(lst_remove_first(l, x))
    n++;
  return n;
}


LIST *lst_sra_bad_case(int n) {
        LIST *l = lst_create();
        int i;
        int k=n/2;

        for(i=0; i<k; i++) {
                lst_push_front(l, 0);
        }
        for(i=0; i<n-k; i++) {
                lst_push_front(l, 1);
        }
        return l;
}


int lst_remove_all_fast(LIST *l, ElemType x) {
        int counter = 0;
        NODE *p = l->front;
        NODE *temp;
        if(p == NULL) 
                return 0;
        while(p->val == x){
                lst_pop_front(l);
                p = l->front;
                counter++;
        }
        
        while(p->next != NULL){
                if(p->next->val == x){
                        temp = p->next;
                        p->next = temp->next;
                        if (temp == l->back){
                                l->back = p;
                        }
                        free(temp);
                        counter++;
                }
                else{
                        p= p->next;
                }
        }
        l->size-=counter;
  return counter;
}

int lst_is_sorted(LIST *l){
        NODE *p = l->front;

        while(p!=NULL && p->next != NULL) {
                if(p->val > p->next->val)
                        return 0;
                p = p->next;
        }
        return 1;
}




void lst_insert_sorted(LIST *l, ElemType x) {
        if(l->front == NULL){
                lst_push_back(l,x);
                return;
        }
        NODE *p = l->front;
        NODE *temp;
        NODE *new = malloc(sizeof(NODE));
        new->val = x;


        if(p->val > x){//if the first value is greater than x  
                /*new->next = l->front;
                l->front = new;*/
                lst_push_front(l,x);
                return;//basically push_front...forgot it existed
        }
        if (l->back->val <= x){
                /*temp = l->back;
                temp->next = new;
                new->next = NULL;
                l->back = new;*/
                lst_push_back(l,x);
                return;//i could also have used push_back...just forgot it existed 
        }
        while(p->next->val <= x && p->next != NULL){
                p = p->next;
        }//moves to the last node which is less/equal to x (duplicates allowed)
        temp = p->next;      
        p->next = new;
        new->next = temp;
        l->size++;   
}


void lst_merge_sorted(LIST *a, LIST *b){
        void lst_merge_sorted(LIST *a, LIST *b);
  
    if(a->front == NULL && b->front == NULL) return;
    if(a->front == NULL && b->front != NULL)
    {
        a->front = b->front;
        b->front=NULL;
        return;
    }
    if(a->front != NULL && b->front == NULL)
    {
        return;
    }
    if(a->front != NULL && b->front != NULL)
    {
        NODE *pa = a->front;
        NODE *pb = b->front;
        NODE *prev;
        if(pb->val < pa->val){
            prev = pb;
            a->front = b->front;
            pb = pb->next;
        }
        else{
            prev = pa;
            pa = pa->next;
        }
        while(pa != NULL && pb != NULL){
            if(pa->val <= pb->val){
                prev->next = pa;
                prev = prev->next;
                pa = pa->next;
            }
            else{
                prev->next = pb;
                prev = prev->next;
                pb = pb->next;
            }
            if(pa == NULL) prev->next = pb;
            if(pb == NULL) prev->next = pa;
        }
        a->back = find_back(a->front);
        b->front=NULL;
      }
  }


                //Prepends all premier b vals that are less than first a val
                /* 
                if(pa->val < pb->val){
                        while(pb->val < pa->val){
                                prev = pb;
                                pb = pb->next;
                        }
                        prev->next = pa;
                        a->front = b->front;
                        b->front = pb;
                }

                while(pa != NULL && pb != NULL){
                        if(pa->val <= pb->val){
                                prev = prev->next;
                                pa = pa->next;
                        }
                        else{
                                prev->next = pb;
                                pb = pb->next;
                                prev->next->next = pa;
                                prev = prev->next;
                                b->front = pb;
                                a->size++;
                                b->size--;
                
                        }
        
        
                }       
                if(!lst_is_empty(b)){
                        lst_concat(a,b);
                }
                //else{free(b);}*/
        




LIST * lst_clone(LIST *a) {
        LIST *clone = lst_create();
        NODE *p = a->front;
        while (p!= NULL){
                lst_push_back(clone, p->val);
                p = p->next; 
        }

  return clone;

}




LIST * lst_from_array(ElemType a[], int n){
        LIST *new = lst_create();

        for (int i = 0; i < n; i++){
                lst_push_back(new, a[i]);
        }

  return new;

}//needs testing


ElemType * lst_to_array(LIST *lst) {
        int *new = malloc(sizeof(int)*lst_length(lst));
        NODE *p = lst->front;
        for (int i = 0; p!= NULL; i++){
                new[i] = p->val;
                p = p->next;
        }
  return new;
}//needs testing 



LIST * lst_prefix(LIST *lst, unsigned int k) {
        LIST *new = lst_create();
        if(lst->size >= k){
                for(int i = 0; i < k; i++){
                        lst_push_back(new, lst->front->val);
                        lst_pop_front(lst);
                }
        }

  return new;

} 





LIST * lst_filter_leq(LIST *lst, ElemType cutoff) {//seg fault when the whole list is cut off
        LIST *new = lst_create();
        if(!lst_is_empty(lst)){
                while(lst->front->val <= cutoff && lst->front != NULL){
                        lst_push_back(new, lst->front->val);
                        lst_pop_front(lst);
                }
                if(lst->front != NULL){
                        NODE *p = lst->front;
                        while(p->next!= NULL){
                                if (p->next->val <= cutoff){
                                        lst_push_back(new, p->next->val);
                                        NODE *temp = p->next;
                                        if (temp == lst->back)
                                                lst->back = p;
                                        p->next = temp->next;
                                        free(temp);
                                        lst->size--;//decrement size of list
                                }
                                else{
                                        p = p->next;
                                }
                        }
        
                }
        }

        return new;

} 


void lst_concat(LIST *a, LIST *b) {

    if(a->front == NULL && b->front == NULL) return;

    if(a->front != NULL && b->front == NULL) return;

    if (a->front == NULL && b->front != NULL){

        a->front = b->front;

        a->back = b->back;

        a->size = b->size;

        b->front=NULL;

        return;

    }

    if(a->front == b->front)

        return;//if they are the same list

    a->back->next = b->front;

    a->size += b->size;

    a->back = b->back;

    b->front=NULL;

}
