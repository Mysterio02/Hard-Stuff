#include <math.h>
#include <limits>
#include <string>
#include <map>
#include <set>
#include "myrandom.h"

using namespace std;

constexpr double lowest_double = std::numeric_limits<double>::lowest();

/* Type: Question
 *
 * Type representing a personality quiz question.
 */
struct Question {
    string questionText;  // Text of the question
    map<char, int> factors;   // Map from factors to +1 or -1
    friend bool operator< (const Question& lhs, const Question& rhs) {
        return lhs.questionText < rhs.questionText;
    }
    friend bool operator== (const Question& lhs, const Question& rhs) {
        return lhs.questionText == rhs.questionText;
    }
    friend bool operator!= (const Question& lhs, const Question& rhs) {
        return lhs.questionText != rhs.questionText;
    }
};

/* Type: Person
 *
 * Type representing a person, used to represent people when determining
 * who's the closest match to the user.
 */
struct Person {
    string name;      // Name of the person
    map<char, int> scores;  // Map from factors to +1 or -1
    friend bool operator< (const Person& lhs,   const Person& rhs) {
        return lhs.name < rhs.name;
    }
    friend bool operator== (const Person& lhs, const Person& rhs) {
        return lhs.name == rhs.name;
    }
    friend bool operator!= (const Person& lhs, const Person& rhs) {
        return lhs.name != rhs.name;
    }
};

/* randomElement
 *
 * This function selects, at random, a Question from the inputted questions set
 * and returns the question.  Note, this function does not remove the randomly
 * selected question from the set.
*/
Question randomElement(set<Question>& questions) {
    int ind = randomInteger(0, (int)questions.size()-1);
    int i = 0;
    for (auto e : questions) {
        if (i == ind) {
            return e;
        }
        i++;
    }
    return {};
}


Question randomQuestionFrom(set<Question>& unaskedQuestions) {
  if (unaskedQuestions.size() == 0) {
    throw out_of_range("set: empty");
  } else {
    Question chosenQuestion;
    chosenQuestion = randomElement(unaskedQuestions);
    unaskedQuestions.erase(chosenQuestion);

    return chosenQuestion;
  }
}

// userInScore: Convert user's input score that can be used to
// find "OCEAN" scores

int userInScore(int userScore) {
  if (userScore == 5) {
    return 2;
  } else if (userScore == 4) {
    return 1;
  } else if (userScore == 3) {
    return 0;
  } else if (userScore == 2) {
    return -1;
  } else if (userScore == 1) {
    return -2;
  } else {
    return userScore -3;
  }
}

// newScore: Adds or updates "OCEAN" score in score map
void newScore(map<char, int> &scores, char ch, int factor, int userScore) {
  int oldScore = 0;
  if (scores.count(ch)) {
    oldScore = scores[ch];
  }
  int oceanScore = userInScore(userScore);
  scores[ch] = oldScore + factor * oceanScore;
}

map<char, int> scoresFrom(map<Question, int>& answers) {
  map<char, int> scores;
  for (auto &e : answers) {
    for (auto &f : e.first.factors) {
      newScore(scores, f.first,
        e.first.factors.at(f.first), e.second);
    }
  }
  return scores;
}

map<char, double> normalize(map<char, int>& scores) {
    map<char, double> normalizedScores;
  double sum = 0;
  for (auto &e : scores) {
    sum += pow(e.second, 2);
    normalizedScores[e.first] = e.second;
  }
// If score is in negative
  double sqrtSum = sqrt(double(sum));
  if (sqrtSum == 0) {
    throw out_of_range("cannot normalize");
  }
  for (auto &e : scores) {
    normalizedScores[e.first] = double(e.second) / sqrtSum;
  }
  return normalizedScores;
}

double cosineSimilarityOf(const map<char, double>& lhs,
                          const map<char, double>& rhs) {
    double coSimilarity = 0;
  for (auto &e : lhs) {
    for (auto &f : rhs) {
      if (e.first == f.first) {
        coSimilarity += e.second * f.second;
      }
    }
  }
  return coSimilarity;
}

Person mostSimilarTo(map<char, int>& scores, set<Person>& people) {
    if (people.size() == 0) {
      throw out_of_range ("set empty");
    }

  double prevcoSimilarity = lowest_double;

  Person mostSimilarPerson;
  for (Person e : people) {
    map<char, double> normPeopleScores = normalize(e.scores);
    map<char, double> normUserScores = normalize(scores);

    double coSimilarity = cosineSimilarityOf(normUserScores, normPeopleScores);

    if (coSimilarity > prevcoSimilarity) {
      prevcoSimilarity = coSimilarity;
      mostSimilarPerson = e;
    }
  }
  return mostSimilarPerson;
}