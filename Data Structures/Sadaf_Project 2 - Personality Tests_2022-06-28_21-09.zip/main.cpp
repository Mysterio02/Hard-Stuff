// CS 251 Project 2
// Madiha Sadaf
// Creative Component:
// The mine.people file contains 
// characters from Avengers. It's an 
// Avenger personality test!!

#include <set>
#include <vector>
#include <map>
#include <fstream>
#include <sstream>
#include <string>
#include <iostream>
#include "driver.h"

using namespace std;

// Functions
void ParseLine(string line, string &text, map<char, int> &factorsMap);
void ParseQuestions(string filename, set<Question> &unaskedQuestions);
void ParsePeople(string filename, set<Person> &people);
string GetFileName(int fileName);
void AskQuestions(set<Question> &unaskedQuestions, map<char, int> &scores);
int ChooseTests(set<Person> &people, map<char, int> &scores);

int main() {
    cout << "Welcome to the Personality Quiz!\n" << endl;

  // ask questions
  set<Question> unaskedQuestions;
  map<char, int> scores;
  AskQuestions(unaskedQuestions, scores);

  // compare user inputs to tests
  set<Person> people;
  int valid = ChooseTests(people, scores);
    return 0;
}

// Personality Test

void AskQuestions(set<Question> &unaskedQuestions, map<char, int> &scores) {
  ParseQuestions("questions.txt", unaskedQuestions);
  int QuesNum;
  cout << "Choose number of questions: ";
  cin >> QuesNum;
  cout << "\n";

  map<Question, int> answers;
  int count = 0;
  while (count < QuesNum) {
    cout << "How much do you agree with this statement?" << endl;
    Question chosenQuestion = randomQuestionFrom(unaskedQuestions);
    cout << "\"" <<chosenQuestion.questionText << "\"\n" << endl;

    cout << "1. Strongly disagree" << endl;
    cout << "2. Disagree" << endl;
    cout << "3. Neutral" << endl;
    cout << "4. Agree" << endl;
    cout << "5. Strongly agree\n" << endl;
    int userQuesInput;
    cout << "Enter your answer here (1-5): ""\n";
    cin >> userQuesInput;

    answers[chosenQuestion] = userQuesInput;
    unaskedQuestions.erase(chosenQuestion);
    count++;
  }
  scores = scoresFrom(answers);
}

int ChooseTests(set<Person> &people, map<char, int> &scores) {
  int fileName;
  string filename;
  do {
    cout << "1. BabyAnimals"<< endl;
    cout << "2. Brooklyn99"<< endl;
    cout << "3. Disney"<< endl;
    cout << "4. Hogwarts"<< endl;
    cout << "5. MyersBriggs"<< endl;
    cout << "6. SesameStreet"<< endl;
    cout << "7. StarWars"<< endl;
    cout << "8. Vegetables"<< endl;
    cout << "9. mine"<< endl;
    cout << "0. To end program."<< endl;
    cout << "\nChoose test number (1-9, or 0 to end): ";
    cin >> fileName;

    filename = GetFileName(fileName);
    if (filename == "goodbye") {
      return 0;
    }
    ParsePeople(filename, people);
    Person mostSimilarPerson;
    mostSimilarPerson = mostSimilarTo(scores, people);
    cout << "You got " << mostSimilarPerson.name << "!\n" << endl;
    people.clear();
  }
    while (fileName != 0);
  return 0;
}

// Parse the input to find text and add to OCEANstd= values

void ParseLine(string line, string &text, map<char, int> &inputMap) {
  stringstream s(line);
  getline(s, text, '.');
  string temp;
  getline(s, temp, ' ');
  string mapValues;
  while (!s.eof()) {
    getline(s, mapValues, ' ');
    char ch = mapValues[0];
    int Pos = mapValues.find(":");
    int num = stoi(mapValues.substr(Pos + 1));
    inputMap[ch] = num;
  }
}

// Parse through questions to add them to a set

void ParseQuestions(string filename, set<Question> &unaskedQuestions) {
  ifstream infile(filename);
  string line;

  while (!infile.eof()) {
    getline(infile, line, '\n');

    if (!infile.fail()) {
      string text;
      map<char, int> factorsMap;
      ParseLine(line, text, factorsMap);

      Question question;
      question. questionText = text + ".";
      question.factors = factorsMap;
      unaskedQuestions.insert(question);
    }
  }
}

// Parse through test file of people add them // to a set

void ParsePeople(string filename, set<Person> &people) {
  ifstream infile(filename);
  string line;

  while (!infile.eof()) {
    getline(infile, line, '\n');

    if (!infile.fail()) {
      string text;
      map<char, int> factorsMap;
      ParseLine(line, text, factorsMap);

      Person person;
      person.name = text;
      person.scores = factorsMap;
      people.insert(person);
    }
  }
}

// Gets filename based on user input

string GetFileName(int fileName) {
  if (fileName == 1) {
    return "BabyAnimals.people";
    } else if (fileName == 2) {
    return "Brooklyn99.people";
    } else if (fileName == 3) {
    return "Disney.people";
    } else if (fileName == 4) {
    return "Hogwarts.people";
    } else if (fileName == 5) {
    return "MyersBriggs.people";
    } else if (fileName == 6) {
    return "SesameStreet.people";
    } else if (fileName == 7) {
    return "StarWars.people";
    } else if (fileName == 8) {
    return "Vegetables.people";
    } else if (fileName == 9) {
    return "mine.people";
    } else if (fileName == 0) {
    cout << "Goodbye!" << endl;
    return "goodbye";
    } else {
    return "goodbye";
    }
  }