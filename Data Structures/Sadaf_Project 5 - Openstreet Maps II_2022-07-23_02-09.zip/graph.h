// graph.h <Starter Code>
// < Your name >
//
// Basic graph class using adjacency matrix representation.  Currently
// limited to a graph with at most 100 vertices.
//
// University of Illinois at Chicago
// CS 251: Fall 2021
// Project #7 - Openstreet Maps
//

#pragma once

#include <iostream>
#include <stdexcept>
#include <vector>
#include <set>
#include <map>
#include <unordered_map>
using namespace std;

template <typename VertexT, typename WeightT> class graph {
 private:
  struct Node {
    VertexT vertex;
    WeightT weight;
  };
  set<VertexT> vertices;
  unordered_map<VertexT, unordered_map<VertexT, WeightT>> adjList;
  vector<VertexT> vertexVector;

 public:
  //
  // constructor:
  //

  graph() {}

  //
  // NumVertices
  //
  // Returns the # of vertices currently in the graph.
  //
  int NumVertices() const { 
    return static_cast<int>(this->vertices.size()); 
    }

  //
  // NumEdges
  //
  // Returns the # of edges currently in the graph.
  //
  int NumEdges() const {
    int count = 0;
    for (const auto &vertex : vertices) {
      int edges = adjList.at(vertex).size();
      count += edges;
    }
    return count;
  }

  //
  // addVertex
  //
  // Adds the vertex v to the graph if there's room, and if so
  // returns true.  If the graph is full, or the vertex already
  // exists in the graph, then false is returned.
  //
  bool addVertex(VertexT V) {
    if (vertices.count(V) != 0) {
      return false;
    }
    vertices.insert(V);
    vertexVector.push_back(V);
    unordered_map<VertexT, WeightT> temp;
    adjList[V] = temp;
    return true;
  }

  //
  // addEdge
  //
  // Adds the edge (from, to, weight) to the graph, and returns
  // true.  If the vertices do not exist false is returned.
  //
  // NOTE: if the edge already exists, the existing edge weight
  // is overwritten with the new edge weight.
  //
  bool addEdge(VertexT from, VertexT to, WeightT weight) {
    if (vertices.count(from) == 0) {
      return false;
    }
    if (vertices.count(to) == 0) {
      return false;
    }
    if (adjList.at(from).count(to) != 0) {
      adjList[from][to] = weight;
    }
    adjList[from].insert({to, weight});
    return true;
  }

  //
  // getWeight
  //
  // Returns the weight associated with a given edge.  If
  // the edge exists, the weight is returned via the reference
  // parameter and true is returned.  If the edge does not
  // exist, the weight parameter is unchanged and false is
  // returned.
  //
  bool getWeight(VertexT from, VertexT to, WeightT &weight) const {
    if (vertices.count(from) == 0) {
      return false;
    }
    if (vertices.count(to) == 0) {
      return false;
    }
    if (adjList.at(from).count(to) == 0) {
      return false;
    }

    weight = adjList.at(from).at(to);
    return true;
  }

  //
  // neighbors
  //
  // Returns a set containing the neighbors of v, i.e. all
  // vertices that can be reached from v along one edge.
  // Since a set is returned, the neighbors are returned in
  // sorted order; use foreach to iterate through the set.
  //
  set<VertexT> neighbors(VertexT V) const {
    set<VertexT> result;
    if (vertices.count(V) == 0) {
      return result;
    }
    if (adjList.at(V).size() == 0) {
      return result;
    }
    for (auto const &x : adjList.at(V)) {
      result.insert(x.first);
    }
    return result;
  }

  //
  // getVertices
  //
  // Returns a vector containing all the vertices currently in
  // the graph.
  //
  vector<VertexT> getVertices() const { 
    return vertexVector;
    }

  //
  // dump
  //
  // Dumps the internal state of the graph for debugging purposes.
  //
  // Example:
  //    graph<string,int>  G(26);
  //    ...
  //    G.dump(cout);  // dump to console
  //
  void dump(ostream &output) const {
    output << "***************************************************" << endl;
    output << "********************* GRAPH ***********************" << endl;

    output << "**Num vertices: " << this->NumVertices() << endl;
    output << "**Num edges: " << this->NumEdges() << endl;

    output << endl;
    output << "**Vertices:" << endl;
    for (auto &vertex : vertices) {
      int count = 0;
      output << " " << count << ". " << vertex << endl;
      count++;
    }
    output << endl;
    output << "**Edges:" << endl;
    for (auto &vertex : vertices) {
      output << "row " << vertex << " ";
      for (auto &node : adjList.at(vertex)) {
        output << node.first << " ";
      }
      output << endl;
    }
    output << "**************************************************" << endl;
  }
};