// application.cpp <Starter Code>
// <Your name>
//
// University of Illinois at Chicago
// CS 251: Fall 2021
// Project #7 - Openstreet Maps
//
// References:
// TinyXML: https://github.com/leethomason/tinyxml2
// OpenStreetMap: https://www.openstreetmap.org
// OpenStreetMap docs:
//   https://wiki.openstreetmap.org/wiki/Main_Page
//   https://wiki.openstreetmap.org/wiki/Map_Features
//   https://wiki.openstreetmap.org/wiki/Node
//   https://wiki.openstreetmap.org/wiki/Way
//   https://wiki.openstreetmap.org/wiki/Relation
//

#include <cassert>
#include <cstdlib>
#include <cstring>
#include <iomanip> /*setprecision*/
#include <iostream>
#include <limits>
#include <map>
#include <queue>
#include <string>
#include <vector>

#include "dist.h"
#include "graph.h"
#include "osm.h"
#include "tinyxml2.h"

using namespace std;
using namespace tinyxml2;
const double INF = numeric_limits<double>::max();

// Class to implement priority queue -> class prioritize

class prioritize {
 public:
  bool operator()(const pair<long long, double>& p1,
                  const pair<long long, double>& p2) const {
    if (p1.second == p2.second) {
      return p1.first > p2.first;
    }
    return p1.second > p2.second;
  }
};

// Dijkstra -> Used to find shortest possible path between the vertices

map<long long, long long> Dijkstra(graph<long long, double> &G,
                                   long long startV,
                                   map<long long, double> &distances) {
  set<long long> predV;

  priority_queue<pair<long long, double>, vector<pair<long long, double>>,
                 prioritize>
      unvisitedQueue;

  map<long long, long long> prev;

  for (auto &v : G.getVertices()) {
    distances[v] = INF;
    prev[v] = 0;
    unvisitedQueue.push(make_pair(v, INF));
  }
  distances[startV] = 0;
  unvisitedQueue.push(make_pair(startV, 0));

  pair<long long, double> currV;
  double edgeWeight;
  double altDist;

  while (!unvisitedQueue.empty()) {
    currV = unvisitedQueue.top();
    unvisitedQueue.pop();
    if (distances[currV.first] == INF) {
      break;
    } else if (predV.count(currV.first) > 0) {
      continue;
    } else {
      predV.insert(currV.first);
    }
    for (long long x : G.neighbors(currV.first)) {
      G.getWeight(currV.first, x, edgeWeight);
      altDist = distances[currV.first] + edgeWeight;
      if (altDist < distances[x]) {
        distances[x] = altDist;
        prev[x] = currV.first;
        unvisitedQueue.push(make_pair(x, altDist));
      }
    }
  }
  return prev;
}

//
// Implement your creative component application here
// TO DO: add arguments
//
void creative() {}


// search building that user input
BuildingInfo searchBuilding(string query, vector<BuildingInfo> &Buildings) {
  for (auto b : Buildings) {
    if (b.Abbrev == query) {
      return b;
    } else if (b.Fullname.find(query) != string::npos) {
      return b;
    }
  }
  return {};  // failed to find
}

// Gives closest building location to user's building
BuildingInfo searchMidBuilding(BuildingInfo b1, BuildingInfo b2,
                          vector<BuildingInfo> &Buildings, set<string> s) {
  double min = INF;
  double dist;
  Coordinates c1 = b1.Coords;
  Coordinates c2 = b2.Coords;
  Coordinates coord = centerBetween2Points(c1.Lat, c1.Lon, c2.Lat, c2.Lon);
  BuildingInfo nearBuild;
  for (auto &b : Buildings) {
    dist = distBetween2Points(coord.Lat, coord.Lon, b.Coords.Lat, b.Coords.Lon);
    if (dist < min && s.count(b.Fullname) == 0) {
      min = dist;
      nearBuild = b;
    }
  }
  return nearBuild;
}

long long findNode(BuildingInfo query, vector<FootwayInfo> f,
                   map<long long, Coordinates> nodes) {
  double min = INF;
  long long near;
  double dist;
  for (auto x : f) {
    for (auto y : x.Nodes) {
      dist = distBetween2Points(nodes[y].Lat, nodes[y].Lon, query.Coords.Lat,
                                query.Coords.Lon);
      if (dist < min) {
        min = dist;
        near = y;
      }
    }
  }
  return near;
}

void printPath(map<long long, long long> &prev, long long &start,
               long long &curr) {
  if (start == curr) {
    cout << "Path: " << start;
    return;
  }
  printPath(prev, start, prev[curr]);
  cout << "->" << curr;
}

//
// Implement your standard application here
// TO DO: add a parameter for the graph you make.
//
void application(map<long long, Coordinates> &Nodes,
                 vector<FootwayInfo> &Footways, vector<BuildingInfo> &Buildings,
                 graph<long long, double> &G) {
  string person1Building, person2Building;

  cout << endl;
  cout << "Enter person 1's building (partial name or abbreviation), or #> ";
  getline(cin, person1Building);

  while (person1Building != "#") {
    cout << "Enter person 2's building (partial name or abbreviation)> ";
    getline(cin, person2Building);
    BuildingInfo building1 = searchBuilding(person1Building, Buildings);
    BuildingInfo building2 = searchBuilding(person2Building, Buildings);
    if (building1.Fullname == "") {
      cout << "Person 1's building not found" << endl;
      cout << "\nEnter person 1's building (partial name or abbreviation), or "
              "#> ";
      getline(cin, person1Building);
      continue;  // breaks the iteration and continues with the other
    }
    if (building2.Fullname == "") {
      cout << "Person 2's building not found" << endl;
      cout << "\nEnter person 1's building (partial name or abbreviation), or "
              "#> ";
      getline(cin, person1Building);
      continue;
    }

    set<string> preV;
    BuildingInfo midBuilding =
        searchMidBuilding(building1, building2, Buildings, preV);

    cout << "Person 1's point:" << endl;
    cout << " " << building1.Fullname << endl;
    cout << " (" << building1.Coords.Lat << ", ";
    cout << building1.Coords.Lon << ")" << endl;
    cout << "Person 2's point:" << endl;
    cout << " " << building2.Fullname << endl;
    cout << " (" << building2.Coords.Lat << ", ";
    cout << building2.Coords.Lon << ")" << endl;
    cout << "Destination Building:" << endl;
    cout << " " << midBuilding.Fullname << endl;
    cout << " (" << midBuilding.Coords.Lat << ", ";
    cout << midBuilding.Coords.Lon << ")" << endl;

    long long node1 = findNode(building1, Footways, Nodes);
    long long node2 = findNode(building2, Footways, Nodes);
    long long midNode = findNode(midBuilding, Footways, Nodes);

    cout << endl;
    cout << "Nearest P1 node:" << endl;
    cout << " " << node1 << endl;
    cout << " (" << Nodes[node1].Lat << ", ";
    cout << Nodes[node1].Lon << ")" << endl;
    cout << "Nearest P2 node:" << endl;
    cout << " " << node2 << endl;
    cout << " (" << Nodes[node2].Lat << ", ";
    cout << Nodes[node2].Lon << ")" << endl;
    cout << "Nearest destination node:" << endl;
    cout << " " << midNode << endl;
    cout << " (" << Nodes[midNode].Lat << ", ";
    cout << Nodes[midNode].Lon << ")" << endl;
    cout << endl;

    map<long long, double> dist1;
    map<long long, double> dist2;
    map<long long, long long> prev1 = Dijkstra(G, node1, dist1);
    map<long long, long long> prev2 = Dijkstra(G, node2, dist2);

    if (dist1[node2] >= INF) {
      cout << "Sorry, destination unreachable." << endl;
      cout << "\nEnter person 1's building (partial name or abbreviation), or "
              "#> ";
      getline(cin, person1Building);
      continue;
    }

    while (true) {
      if (dist1[midNode] >= INF || dist2[midNode] >= INF) {
        cout << "At least one person was unable to reach the destination "
                "building. Finding next closest building..."
             << endl
             << endl;
        preV.insert(midBuilding.Fullname);
        midBuilding = searchMidBuilding(building1, building2, Buildings, preV);
        midNode = findNode(midBuilding, Footways, Nodes);

        cout << "New destination building:" << endl;
        cout << " " << midBuilding.Fullname << endl;
        cout << " (" << midBuilding.Coords.Lat << ", ";
        cout << midBuilding.Coords.Lon << ")" << endl;
        cout << "Nearest destination node:" << endl;
        cout << " " << midNode << endl;
        cout << " (" << Nodes[midNode].Lat << ", ";
        cout << Nodes[midNode].Lon << ")" << endl;
      } else {
        cout << "Person 1's distance to dest: " << dist1[midNode] << " miles"
             << endl;
        printPath(prev1, node1, midNode);
        cout << endl << endl;
        cout << "Person 2's distance to dest: " << dist2[midNode] << " miles"
             << endl;
        printPath(prev2, node2, midNode);
        cout << endl;
        break;
      }
    }
    //
    // another navigation?
    //
    cout << endl;
    cout << "Enter person 1's building (partial name or abbreviation), or #> ";
    getline(cin, person1Building);
  }
}

int main() {
  // maps a Node ID to it's coordinates (lat, lon)
  map<long long, Coordinates> Nodes;
  // info about each footway, in no particular order
  vector<FootwayInfo> Footways;
  // info about each building, in no particular order
  vector<BuildingInfo> Buildings;
  XMLDocument xmldoc;

  cout << "** Navigating UIC open street map **" << endl;
  cout << endl;
  cout << std::setprecision(8);

  string def_filename = "map.osm";
  string filename;

  cout << "Enter map filename> ";
  getline(cin, filename);

  if (filename == "") {
    filename = def_filename;
  }

  //
  // Load XML-based map file
  //
  if (!LoadOpenStreetMap(filename, xmldoc)) {
    cout << "**Error: unable to load open street map." << endl;
    cout << endl;
    return 0;
  }

  //
  // Read the nodes, which are the various known positions on the map:
  //
  int nodeCount = ReadMapNodes(xmldoc, Nodes);

  //
  // Read the footways, which are the walking paths:
  //
  int footwayCount = ReadFootways(xmldoc, Footways);

  //
  // Read the university buildings:
  //
  int buildingCount = ReadUniversityBuildings(xmldoc, Nodes, Buildings);

  //
  // Stats
  //
  assert(nodeCount == (int)Nodes.size());
  assert(footwayCount == (int)Footways.size());
  assert(buildingCount == (int)Buildings.size());

  cout << endl;
  cout << "# of nodes: " << Nodes.size() << endl;
  cout << "# of footways: " << Footways.size() << endl;
  cout << "# of buildings: " << Buildings.size() << endl;

  graph<long long, double> G;
  for (auto &x : Nodes) {
    G.addVertex(x.first);
  }

  for (auto x : Footways) {
    long long l1;
    long long l2;
    for (int i = 0; i < x.Nodes.size() - 1; i++) {
      l1 = x.Nodes[i];
      l2 = x.Nodes[i + 1];
      double dist = distBetween2Points(Nodes[l1].Lat, Nodes[l1].Lon,
                                       Nodes[l2].Lat, Nodes[l2].Lon);
      G.addEdge(l1, l2, dist);
      G.addEdge(l2, l1, dist);
    }
  }

  cout << "# of vertices: " << G.NumVertices() << endl;
  cout << "# of edges: " << G.NumEdges() << endl;
  cout << endl;

  //
  // Menu
  //
  string userInput;
  cout << "Enter \"a\" for the standard application or "
       << "\"c\" for the creative component application> ";
  getline(cin, userInput);
  if (userInput == "a") {
    // TO DO: add argument for the graph you make.
    application(Nodes, Footways, Buildings, G);
  } else if (userInput == "c") {
    // TO DO: add arguments
    creative();
  }
  //
  // done:
  //
  cout << "** Done **" << endl;
  return 0;
}