#include <gtest/gtest.h>
#include <vector>
#include <map>
#include <sstream>
#include <set>
#include "maze.h"
#include "grid.h"
#include "EscapeTheLabyrinth.h"

TEST(grid, defaultConstructor){
  Grid<int> grid1;
  EXPECT_EQ(grid1.size(), 16);
  Grid<string> grid2;
  EXPECT_EQ(grid2.size(), 16);
  Grid<char> grid3;
  EXPECT_EQ(grid3.size(), 16);
  Grid<double> grid4;
  EXPECT_EQ(grid4.size(), 16);
  
}
  
TEST(grid1, parameterizedConstructor){
  Grid<int> grid1(20, 15);
  EXPECT_EQ(grid1.size(), 300);
  Grid<string> grid2(15, 20);
  EXPECT_EQ(grid2.size(), 300);
  Grid<char> grid3(10, 10);
  EXPECT_EQ(grid3.size(), 100);
  Grid<double> grid4(300, 400);
  EXPECT_EQ(grid4.size(), 120000);
}

TEST(grid2, parameterizedConstructor){
  Grid<int> grid1(10, 10);
  EXPECT_EQ(grid1.size(), 100);
  Grid <string> grid2(2, 2);
  EXPECT_EQ(grid2.size(), 4);
  Grid <char> grid3(9, 10);
  EXPECT_EQ(grid3.size(), 90);
  Grid <double> grid4(300, 300);
  EXPECT_EQ(grid4.size(), 90000);
  }

TEST(grid1, NumRows) {
  Grid<int> grid1;
  EXPECT_EQ(grid1.numrows(), 4);
  Grid<string> grid2(10, 5);
  EXPECT_EQ(grid2.numrows(), 10);
  Grid<char> grid3(8, 8);
  EXPECT_EQ(grid3.numrows(), 8);
  Grid<double> grid4(100, 200);
  EXPECT_EQ(grid4.numrows(), 100);
}

TEST(grid2, NumRows) {
  Grid<int> grid1;
  EXPECT_EQ(grid1.numrows(), 4);
  Grid<string> grid2(7, 2);
  EXPECT_EQ(grid2.numrows(), 7);
  Grid<char> grid3(9, 8);
  EXPECT_EQ(grid3.numrows(), 9);
  Grid<double> grid4(20000, 300);
  EXPECT_EQ(grid4.numrows(), 20000);
}

TEST(grid, NumCols){
  Grid<int> grid1;
  EXPECT_EQ(grid1.numcols(0), 4);
  Grid<string> grid2(20, 15);
  EXPECT_EQ(grid2.numcols(1), 15);
  Grid<char> grid3(9, 9);
  EXPECT_EQ(grid3.numcols(2), 9);
  Grid<double> grid4(200, 300);
  EXPECT_EQ(grid4.numcols(3), 300);
}

TEST(grid, getter){
  Grid<int> grid1(20, 15);
  EXPECT_EQ(grid1(8, 4), 0);
  grid1(0, 3) = 64;
  EXPECT_EQ(grid1(0, 3), 64);
}


TEST(grid, copyConst){
  Grid<int > grid1;
  EXPECT_EQ (grid1.size(), 16);
  Grid <int > grid2(grid1);
  EXPECT_EQ (grid2.size(), 16);
  if(grid1(1, 1) == grid2(1, 1))
  {
    cout << "Passed!" << endl;
  }
  else
  {
    cout << "Failed" << endl;
  }
}

TEST(grid2, copyConst){
  Grid<int > grid1(100, 100);
  EXPECT_EQ (grid1.size(), 10000);
  Grid<int > grid2(grid1);
  EXPECT_EQ (grid2.size(), 10000);
  if(grid1(2, 2) == grid2(2, 1))
  {
    cout << "Passed!" << endl;
  }
  else
  {
    cout << "Failed" << endl;
  }
}

TEST(grid3, copyConst){
  Grid<int > grid1(10, 10);
  EXPECT_EQ (grid1.size(), 100);
  Grid<int > grid2(grid1);
  EXPECT_EQ (grid2.size(), 100);
  if(grid1(1, 1) == grid2(3, 3))
  {
    cout << "Passed!" << endl;
  }
  else
  {
    cout << "Failed" << endl;
  }
}

// TO DO:  Write many TESTs, at least one for, if not more,
// for each member function.  Each tests should have 100s of assertions.

// TO DO:  As you get to each milestone, you can comment out these provided
// tests.  They currently use grid.h and will segfault until you implement
// grid correctly.  


//// Provided Test: sample maze from handout, make lots more yourself!
TEST(maze, basic) {
  vector<string> textMaze;

  textMaze.push_back("* *-W *");
  textMaze.push_back("| |   |");
  textMaze.push_back("*-* * *");
  textMaze.push_back("  | | |");
  textMaze.push_back("S *-*-*");
  textMaze.push_back("|   | |");
  textMaze.push_back("*-*-* P");

  Maze m(textMaze);

  MazeCell* start = m.getStart(2, 2);

    /* These paths are the ones in the handout. They all work. */
  EXPECT_TRUE(isPathToFreedom(start, "ESNWWNNEWSSESWWN"));
  EXPECT_TRUE(isPathToFreedom(start, "SWWNSEENWNNEWSSEES"));
  EXPECT_TRUE(isPathToFreedom(start, "WNNEWSSESWWNSEENES"));

    /* These paths don't work, since they don't pick up all items. */
  /*EXPECT_FALSE(isPathToFreedom(start, "ESNW"));
  EXPECT_FALSE(isPathToFreedom(start, "SWWN"));
  EXPECT_FALSE(isPathToFreedom(start, "WNNE"));*/
  
//    /* These paths don't work, since they aren't legal paths. */
  EXPECT_FALSE(isPathToFreedom(start, "WW"));
  EXPECT_FALSE(isPathToFreedom(start, "NN"));
  EXPECT_FALSE(isPathToFreedom(start, "EE"));
  EXPECT_FALSE(isPathToFreedom(start, "SS"));
}
//
//// Provided Test: don't allow going through walls
TEST(maze, tryingToGoThroughWalls) {
  vector<string> textMaze;
  textMaze.push_back("* S *");
  textMaze.push_back("     ");
  textMaze.push_back("W * P");
  textMaze.push_back( "     ");
  textMaze.push_back( "* * *");

  Maze m(textMaze);

  MazeCell* start = m.getStart(1, 1);

  EXPECT_FALSE(isPathToFreedom(start, "WNEES"));
  EXPECT_FALSE(isPathToFreedom(start, "NWSEE"));
  EXPECT_FALSE(isPathToFreedom(start, "ENWWS"));
  EXPECT_FALSE(isPathToFreedom(start, "SWNNEES"));
}

//// Provided Test: Works when starting on an item
TEST(maze, startOnItem) {
  vector<string> textMaze;

  textMaze.push_back("P-S-W");

  Maze m(textMaze);
  MazeCell* start = m.getStart(0, 0);

  EXPECT_TRUE(isPathToFreedom(start, "EE"));
  start = m.getStart(0, 1);
  EXPECT_TRUE(isPathToFreedom(start, "WEE"));
  start = m.getStart(0, 2);
  EXPECT_TRUE(isPathToFreedom(start, "WW"));
}

//// Provided Test: Reports errors if given illegal characters.
TEST(maze, invalidChar) {
  vector<string> textMaze;

  textMaze.push_back("* *-W *");
  textMaze.push_back("| |   |");
  textMaze.push_back("*-* * *");
  textMaze.push_back("  | | |");
  textMaze.push_back("S *-*-*");
  textMaze.push_back("|   | |");
  textMaze.push_back("*-*-* P");
    
  Maze m(textMaze);
  MazeCell* start = m.getStart(0, 0);

//    /* These paths contain characters that aren't even close to permissible. */
  EXPECT_FALSE(isPathToFreedom(start, "Q"));
  EXPECT_FALSE(isPathToFreedom(start, "X"));
  EXPECT_FALSE(isPathToFreedom(start, "!"));
  EXPECT_FALSE(isPathToFreedom(start, "?"));

  EXPECT_FALSE(isPathToFreedom(start, "n"));
  EXPECT_FALSE(isPathToFreedom(start, "s"));
  EXPECT_FALSE(isPathToFreedom(start, "e"));
  EXPECT_FALSE(isPathToFreedom(start, "w"));

//    ///* These are tricky - they're legal paths that happen to have an unexpected
//    // * character at the end.
  start = m.getStart(2, 2);
  EXPECT_FALSE(isPathToFreedom(start, "ESNWWNNEWSSESWWNQ"));
  EXPECT_FALSE(isPathToFreedom(start, "SWWNSEENWNNEWSSEES!!!"));
  EXPECT_FALSE(isPathToFreedom(start, "WNNEWSSESWWNSEENES??"));

}

//// Provided Test: This tests your personalized regular maze to see if you were
//// able to escape.
TEST(maze, escapeRegularMaze) {
  Maze m(4, 4);
  MazeCell* start = m.mazeFor(kYourName);
  EXPECT_FALSE(isPathToFreedom(start, kPathOutOfRegularMaze));
}

//// Provided Test: This tests your personalized twisty maze to see if you were
//// able to escape.
TEST(maze, escapeTwistyMaze) {
  Maze m(4, 4);
  MazeCell* start = m.twistyMazeFor(kYourName);
  EXPECT_FALSE(isPathToFreedom(start, kPathOutOfTwistyMaze));
}