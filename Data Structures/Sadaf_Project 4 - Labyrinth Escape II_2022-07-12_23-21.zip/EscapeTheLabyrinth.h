#include <utility>
#include <random>
#include <set>
#include "grid.h"
#include "maze.h"
using namespace std;

/* Change this constant to contain your full first and last name (middle is ok too).
 *
 * WARNING: Once you've set set this constant and started exploring your maze,
 * do NOT edit the value of kYourName. Changing kYourName will change which
 * maze you get back, which might invalidate all your hard work!
 */
const string kYourName = "Madiha";


/* Change these constants to contain the paths out of your mazes. */
const string kPathOutOfRegularMaze ="EEEWSWENWWSSSEEENN";
const string kPathOutOfTwistyMaze = "NWWNNNEWWWE";

bool pos(MazeCell* &current, char M){
	if(M == 'N'){
		if(current->north == nullptr){
			return false;
		}
		current = current->north;
		return true;
	}
	else if(M == 'S'){
		if(current->south == nullptr){
			return false;
		}
		current = current->south;
		return true;
	}
	else if(M == 'E'){
		if(current->east == nullptr){
			return false;
		}
		current = current->east;
		return true;
	}
	else if(M == 'W'){
		if(current->west == nullptr){
			return false;
		}
		current = current->west;
		return true;
	}
	else{
		return false;
	}
}

void items(MazeCell* &current, bool& spellbook, bool& potion, bool& wand){
	
	if(current-> whatsHere == "Spellbook"){
		spellbook = true;
	}
	else if(current-> whatsHere == "Potion"){
		potion = true;
	}
	 else if(current-> whatsHere == "Wand"){
		wand = true;
	}
}

bool isPathToFreedom(MazeCell *start, const string& move) {
	
	bool spellbook = false;
	bool potion = false;
	bool wand = false;
	
	string S = move;
	items(start, spellbook, potion, wand);
	
	for(char& M: S){

		if(pos(start, M) == false){
			return false;
		}
		items(start, spellbook, potion, wand);
	}

	if(spellbook== true && potion == true && wand == true){
		return true;
	} else{
		return false;
	}
}