#include <iostream>
#include "barchartanimate.h"
using namespace std;


bool testBarDefaultConstructor() {
	Bar b;
    if (b.getName() != "") {
    	cout << "testBarDefaultConstructor: getName failed" << endl;
    	return false;
    } else if (b.getValue() != 0) {
    	cout << "testBarDefaultConstructor: getValue failed" << endl;
    	return false;
    } else if (b.getCategory() != "") {
    	cout << "testBarDefaultConstructor: getCategory failed" << endl;
    	return false;
    }
    cout << "testBarDefaultConstructor: all passed!" << endl;
    return true;
}

bool testBarParamConstructor() {
	Bar b("Chicago", 9234324, "US");
    if (b.getName() != "Chicago") {
    	cout << "testBarParamConstructor: getName failed" << endl;
    	return false;
    } else if (b.getValue() != 9234324) {
    	cout << "testBarParamConstructor: getValue failed" << endl;
    	return false;
    } else if (b.getCategory() != "US") {
    	cout << "testBarParamConstructor: getCategory failed" << endl;
    	return false;
    }
    cout << "testBarParamConstructor: all passed!" << endl;
    return true;
}

bool testBar() {
  Bar b1("bar", 1, "bars");
  Bar b2("bar", 2, "bars");
  Bar b3("bar", 3, "bars");

  // Test the operator (<)
  if (!(b1 < b2)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (b2 < b1) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (b3 < b1) {
    cout << "testBar: failed" << endl;
    return false;
  }

  // Test the operator (>)
  if (!(b2 > b1)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b1 > b2)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b1 > b3)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  
  // Test the operator (<=)
  if (!(b1 <= b2)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b1 <= b3)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b2 <= b1)) {
    cout << "testBar: failed" << endl;
    return false;
  }

  // Test the operator (>=)
  if (!(b2 >= b1)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b1 >= b3)) {
    cout << "testBar: failed" << endl;
    return false;
  }
  if (!(b1 >= b2)) {
    cout << "testBar: failed" << endl;
    return false;
  }

  cout << "testBar: all passed!" << endl;
  return true;
}

// test barchart.h
bool testDump(BarChart bc, string rightOutput) {
  stringstream ss;
  bc.dump(ss);
  if (ss.str() != rightOutput)
  {
    cout << "expected: " << endl << rightOutput << endl;
    cout << "received: " << endl << ss.str() << endl;
    return false;
  }
  return true;
}

bool testBarChartDefaultConstructor() {
  BarChart bc;
  string rightOutput = "frame: \n";
  if (!(testDump(bc, rightOutput)))
  {
    cout << "testBarChartDefaultConstructor: Dump failed" << endl;
    return false;
  }
  cout << "testBarChartDefaultConstructor: all passed!" << endl;
  return true;
}

bool testBarChartParamConstructor() {
  BarChart bc(10);
  string rightOutput = "frame: \n";
  if(!(testDump(bc, rightOutput)))
  {
    cout << "testBarChartParamConstructor: Dump failed" << endl;
    return false;
  }
  cout << "testBarChartParamConstructor: all passed!" << endl;
  return true;
}

bool testBarChartGetFrame() {
  BarChart bc(1);
  bc.setFrame("4");
  string rightOutput = "frame: 4\n";
  if(!(testDump(bc, rightOutput)))
  {
    cout << "testBarChartGetFrame: Dump failed" << endl;
    return false;
  }
  cout << "testBarChartGetFrame: all passed!" << endl;
  return true;
}

bool testBarChartAddBar() {
  BarChart bc1;
  if (bc1.addBar("Chicago", 9234324, "US") == true)
  {
    cout << "testBarChartAddBar: addBar failed" << endl;
    return false;
  }
  BarChart bc2(1);
  if (bc2.addBar("Chicago", 9234324, "US") == false)
  {
    cout << "testBarChartAddBar: addBar failed" << endl;
    return false;
  }
  string rightOutput = "frame: \nChicago 9234324 US\n";
  if(!(testDump(bc2, rightOutput)))
  {
    cout << "testBarChartAddBar: addBar failed" << endl;
    return false;
  }
  if (bc2.getSize() != 1)
  {
    cout << "testBarChartAddBar: getSize failed" << endl;
    return false;
  }
  cout << "testBarChartAddBar: all passed!" << endl;
  return true;
}

bool testBarChartAtOperator() {
  BarChart bc(4);
  bc.addBar("name1", 100, "bars");
  bc.addBar("name2", 200, "bars");
  bc.addBar("name3", 300, "bars");
  bc.addBar("name4", 400, "bars");
  // test this use
  if (bc[3].getName() != "name4")
  {
    cout << "testBarChartAtOperator: GetName failed" << endl;
  }
  //test for out of range
  bool error = false;
  try
  {
    string name = bc[4].getName();
  }
  catch(const std::out_of_range& err)
  {
    error = true;
  }
  if (error == false)
  {
    cout << "testBarChartAtOperator: out_of_range failed" << endl;
  }
  cout << "testBarChartAtOperator: all passed!" << endl;
  return true;
}

bool testBarChartCopyConstructor() {
  BarChart bc1(4);
  bc1.addBar("name1", 100, "bars");
  bc1.addBar("name2", 200, "bars");
  bc1.addBar("name3", 300, "bars");
  bc1.addBar("name4", 400, "bars");
  BarChart bc2(bc1);
  string rightOutput = "frame: \n"
  "name 1 100 bars\n"
  "name 2 200 bars\n"
  "name 3 300 bars\n"
  "name 4 400 bars\n";
  if (!(testDump(bc2, rightOutput)))
  {
    cout << "testBarChartCopyConstructor: Dump failed" << endl;
    return false;
  }
  cout << "testBarChartCopyConstructor: all passed!" << endl;
    return true;
}

bool testbarChartEqualOperator() {
  BarChart bc1(4);
  bc1.addBar("name1", 100, "bars");
  bc1.addBar("name2", 200, "bars");
  bc1.addBar("name3", 300, "bars");
  bc1.addBar("name4", 400, "bars");
  BarChart bc2;
  bc2 = bc1;
  string rightOutput = "frame: \n"
  "name 1 100 bars\n"
  "name 2 200 bars\n"
  "name 3 300 bars\n"
  "name 4 400 bars\n";
  if (!(testDump(bc2, rightOutput)))
  {
    cout << "testbarChartEqualOperator: Dump failed" << endl;
    return false;
  }
  BarChart bc3(4);
  bc3.addBar("name5", 500, "bars");
  bc3.addBar("name6", 600, "bars");
  bc3.addBar("name7", 700, "bars");
  bc3.addBar("name8", 800, "bars");
  bc3 = bc3;
  rightOutput = "frame: \n"
    "name 1 100 bars\n"
    "name 2 200 bars\n"
    "name 3 300 bars\n"
    "name 4 400 bars\n";
  if (!(testDump(bc2, rightOutput)))
  {
    cout << "testbarChartEqualOperator: Dump failed" << endl;
    return false;
  }
  cout << "testbarChartEqualOperator: all passed!" << endl;
    return true;
}

bool testBarChartClear() {
  BarChart bc(4);
  bc.addBar("name1", 100, "bars");
  bc.addBar("name2", 200, "bars");
  bc.addBar("name3", 300, "bars");
  bc.addBar("name4", 400, "bars");
  bc.clear();
  string rightOutput = "frame: \n";
  if (!(testDump(bc, rightOutput)))
  {
    cout << "testBarChartClear: Dump failed" << endl;
    return false;
  }
  cout << "testBarChartClear: all passed!" << endl;
    return true;
}

bool testBarChartGraph() {
  BarChart bc(4);
  bc.addBar("name1", 100, "bars");
  bc.addBar("name2", 200, "bars");
  bc.addBar("name3", 300, "bars");
  bc.addBar("name4", 400, "bars");
  map<string, string> cm;
  bc.graph(cout, cm, 3);
}

bool testBarChartAnimate() {
	string filename = "cities.txt";
	ifstream inFile(filename);
	string title;
	getline(inFile, title);
	string xlabel;
	getline(inFile, xlabel);
	string source;
	getline(inFile, source);

	BarChartAnimate bca(title, xlabel, source);
	
	while (!inFile.eof()) {
		bca.addFrame(inFile);
    }
  bca.animate(cout, 12, 10);
  
  cout << "testBarChartAnimate: all passed!" << endl;
  return true;
  }

int main() {
	testBarDefaultConstructor();
	testBarParamConstructor();
  testBar();
  testBarChartDefaultConstructor();
  testBarChartParamConstructor();
  testBarChartGetFrame();
  testBarChartAddBar();
  testBarChartAtOperator();
  testBarChartCopyConstructor();
  testbarChartEqualOperator();
  testBarChartClear();
  testBarChartGraph();
  testBarChartAnimate();
  return 0;
}