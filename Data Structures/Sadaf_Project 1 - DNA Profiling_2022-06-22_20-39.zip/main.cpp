//
// Project 1 Starter Code - DNA Profiling
// Author: Madiha Sadaf
/* Creative Component: total_dna is the creative component. This finds the total
number of DNA strands found in a text file.

How to run it:
    After the user loads the file and the DNA file, the user needs to type
load_db and hit enter, then type in load_dna 1.txt, press enter again to
initiate the command. After that the user can input: total_dna and it will
output the number of each individual strands found in the file.
*/

#include <fstream>
#include <iostream>
#include <sstream>
#include <string>
#include "ourvector.h"
using namespace std;

struct DNA {
  string name;
  ourvector<int> number;
};

// Firstline function will store the DNA strings in a vector from the first line
void Firstline(string line, ourvector<ourvector<char>> &firstlines) {
  stringstream ss(line);  // using stringstream to parse the line
  string dna_string;
  while (!ss.eof()) {
    getline(ss, dna_string, ',');
    if (!ss.fail()) {
      // ignores the "name" string in the file
      if (dna_string != "name") {
        ourvector<char> temp;
        // loops through the array of string
        for (unsigned int i = 0; i < dna_string.size(); i++) {
          temp.push_back(dna_string[i]);
        }
        firstlines.push_back(temp);  // add into vector
        temp.clear();
      }
    }
  }
}

// parseDNA function will parse the very first line of the small partial DNA
// strands in the database
void parseDNA(string line, DNA &newPerson) {
  stringstream ss(line);
  // get the name of the person
  getline(ss, newPerson.name, ',');
  while (!ss.eof()) {
    string number;
    getline(ss, number, ',');
    int number_convert = stod(
        number);  // convert from string to integer, after getting the numbers
    if (!ss.fail()) {
      newPerson.number.push_back(number_convert);  // add to vector
    }
  }
}

// ClearData function will check
// the database if the user enters a
// new one, the stored database will be cleared
void ClearData(ourvector<ourvector<char>> &firstlines, ourvector<DNA> &person) {
  int firstlines_size = firstlines.size();
  int person_size = person.size();
  if (firstlines_size > 0 && person_size > 0) {
    firstlines.clear();
    person.clear();
  }
}

// load_db function will store the database from the file
void load_db(string filename, ourvector<ourvector<char>> &firstlines,
             ourvector<DNA> &person) {
  cout << "Loading database..." << endl;
  ifstream inFile(filename);  // get the firstlines from the file
  if (!inFile.good()) {
    cout << "Error: unable to open '" << filename << "'" << endl;
  } else {
    ClearData(firstlines, person);
    string line;
     // process first line
    getline(inFile, line, '\n');
    Firstline(line, firstlines);  // get the first line from the database

    while (!inFile.eof()) {
      getline(inFile, line, '\n');
      if (!inFile.fail()) {  // file can be
        // opened and the contents can be accessed
        DNA newPerson;  // store it into a 
        // temporary struct to be pushed back to vector
        parseDNA(line, newPerson);
        person.push_back(newPerson);
      }
    }
  }
}

// displayProcess function will display the processed DNA
void displayProcess(ourvector<ourvector<char>> &firstlines,
                    ourvector<int> &strCount) {
  // firstlines size = strCount size
  int firstlines_size = firstlines.size();
  int strCount_size = strCount.size();
  // check if there are no numbers in the strCount vector
  bool current = false;
  for (int i = 0; i < strCount_size; i++) {
    if (strCount[i] > 0) {
      current = true;
    }
  }
  if (current == false) {
    cout << "No DNA has been processed." << endl;
  } else {
    cout << "DNA processed, STR counts:" << endl;
    // access the firstlines, then put in the number of DNA strings found:
    for (int i = 0; i < firstlines_size; i++) {
      int inside_size = firstlines[i].size();
      for (int j = 0; j < inside_size; j++) {
        cout << firstlines[i][j];
      }
      cout << ": " << strCount[i] << endl;
    }
  }
  cout << endl;
}

// displayData function will display the database from the files
void displayData(ourvector<DNA> &person) {
  if (person.size() != 0) {
    cout << "Database loaded:" << endl;
    for (DNA &p : person) {  // it does not create a copy
      cout << p.name;
      for (int i : p.number) {
        cout << " " << i;
      }
      cout << endl;
    }

  } else {
    cout << "No database loaded." << endl;
  }
}

// displayDNA function will display the DNAs stored in the vectors
void displayDNA(ourvector<char> &letter) {
  if (letter.size() == 0) {
    cout << "No DNA loaded." << endl;
  } else {
    cout << "DNA loaded:" << endl;
    int vectorsize = letter.size();
    for (int i = 0; i < vectorsize; i++) {
      cout << letter[i];
    }
    cout << endl;
  }
  cout << endl;
}

// display function will display the information stored in each vectors
void display(ourvector<ourvector<char>> &firstlines, ourvector<DNA> &person,
             ourvector<char> &letter, ourvector<int> &strCount) {
  displayData(person);
  displayDNA(letter);
  displayProcess(firstlines, strCount);
}

// ClearDNA function will check if there is any DNA files 
// stored and will clear if it is input again
void ClearDNA(ourvector<char> &letter, ourvector<int> &strCount) {
  int letter_size = letter.size();
  int strCount_size = strCount.size();
  // clear both vectors
  if (letter_size > 0) {
    letter.clear();
  }
  if (strCount_size > 0) {
    strCount.clear();
  }
}

// load_dna function will load the DNA file
void load_dna(string filename, ourvector<char> &letter,
              ourvector<int> &strCount) {
  cout << "Loading DNA..." << endl;
  ifstream inFile(filename);
  // if file is invalid
  if (!inFile.good()) {
    cout << "Error: unable to open '" << filename << "'" << endl;
  } else {
    ClearDNA(letter, strCount);
    string letterFromFile;

    while (!inFile.eof()) {
      if (!inFile.fail()) {
        inFile >> letterFromFile;
      }
    }
    int stringsize = letterFromFile.size();
    // load the strings to the vector:
    for (int i = 0; i < stringsize; i++) {
      letter.push_back(letterFromFile[i]);
    }
  }
}

// Comp_DNA function will loop through one strand of the DNA stored in the
// database and compare it with the long strand of DNA
void Comp_DNA(int &i, bool &found, int &loops, ourvector<char> &letters,
              ourvector<ourvector<char>> &firstlines) {
  int firstlines_size =
      firstlines[loops].size();  // the size of one firstlines STR

  for (int j = 0; j < firstlines_size; j++) {
    if (i >= letters.size()) {
      found = false;
      break;
    }
    if (letters[i] != firstlines[loops][j]) {
      found = false;
    }
    i++;
  }
}

// findMatch function will loop through each of the strands until no consecutive
// DNA strands is/are found
void findMatch(int i, int &max_consecutives, int &loops,
               ourvector<ourvector<char>> &firstlines,
               ourvector<char> &letters) {
  int temp = 0;
  bool found = true;

  // loop through DNA strand and compare with the long one
  Comp_DNA(i, found, loops, letters, firstlines);
  while (found == true) {
    temp++;
    Comp_DNA(i, found, loops, letters,
             firstlines);  // keep on looping until no consecutives are found
  }
  if (temp > max_consecutives) {
    max_consecutives =
        temp;  // assigns the max number of consecutives found in the loop
  }
}

// OneStr function will only process one strand of the DNA found in the database
void OneStr(int &loops, ourvector<int> &strCount,
            ourvector<ourvector<char>> &firstlines, ourvector<char> &letters) {
  int max_consecutives = 0;

  int letters_size = letters.size();
  for (int i = 0; i < letters_size; i++) {
    if (letters[i] == firstlines[loops][0]) {
      // check if the first letter matches
      // with the first letter of the STR
      findMatch(i, max_consecutives, loops,
        firstlines, letters);
    }
  }
  strCount.push_back(max_consecutives);  // enter the number for the most
                                         // consecutives found in the DNA
}

// process function will process the DNA from the database and the long DNA
// strand
void process(ourvector<ourvector<char>> &firstlines, ourvector<DNA> &person,
             ourvector<char> &letter, ourvector<int> &strCount) {
  int firstlines_size = firstlines.size();
  int letter_size = letter.size();
  if (firstlines_size == 0) {
    cout << "No database loaded." << endl;
  } else if (letter_size == 0) {
    cout << "No DNA loaded." << endl;
  } else {
    cout << "Processing DNA..." << endl;
    int firstlines_size = firstlines.size();
    int loops = 0;
    // this will go for each vector in the 2d vector to compare it to the DNA
    // strand
    while (loops < firstlines_size) {
      OneStr(loops, strCount, firstlines, letter);
      loops++;
    }
  }
}

// findMatchedPeople function will find the people that match with the number of
// strands
void findMatchedPeople(ourvector<DNA> &person, ourvector<int> &strCount,
                       ourvector<string> &matched_people) {
  int strCount_size = strCount.size();
  for (DNA &p : person) {
    int same_values = 0;
    int count = 0;
    for (int i : p.number) {
      if (strCount[count] == i) {
        same_values++;
      }
      count++;
    }
    if (same_values == strCount_size) {
      matched_people.push_back(p.name);
    }
  }
}

// displayMatchedPeople function will display the people that match with the DNA
void displayMatchedPeople(ourvector<string> &matched_people) {
  int matched_people_size = matched_people.size();

  // no people matched with the DNA
  if (matched_people_size == 0) {
    cout << "Not found in database." << endl;
  }
  // dislay the people that matched with the database
  else if (matched_people_size > 0) {
    cout << "Found in database! DNA matches:";
    for (int i = 0; i < matched_people_size; i++) {
      cout << " " << matched_people[i];
    }
  }
}

// search function will search the people with the same numbers as the DNA
// sequence
void search(ourvector<DNA> &person, ourvector<char> &letter,
            ourvector<int> &strCount) {
  int letter_size = letter.size();
  int person_size = person.size();
  ourvector<string>
      matched_people;  // this vector is for the people that matches with the DNA
  if (person_size == 0) {
    cout << "No Database loaded." << endl;
    return;
  } else if (letter_size == 0) {
    cout << "No DNA loaded." << endl;
    return;
  } else {
    cout << "Searching database..." << endl;
    findMatchedPeople(person, strCount,
                      matched_people);  // find the people who match
    displayMatchedPeople(
        matched_people);  // display the people who match or no matches found
    cout << endl;
  }
}

// findMatch function will match the DNA strands
void findMatch(int i, int &count, int &loops, int firstlines_size,
               ourvector<ourvector<char>> &firstlines,
               ourvector<char> &letters) {
  bool found = true;
  // loop through DNA strand and compare with the big one
  // int inside_size = firstlines[loops][]

  for (int j = 0; j < firstlines_size; j++) {
    if (i >= letters.size())  // the edge case
    {
      return;
    }
    if (letters[i] != firstlines[loops][j]) {
      found = false;
      return;
    }
    i++;
  }

  if (found == true) {
    count++;
  }
}

// countStr function will count the DNA strands that are found both
// consecutively and not
void countStr(int &loops, ourvector<int> &strCount,
              ourvector<ourvector<char>> &firstlines,
              ourvector<char> &letters) {
  int count = 0;
  int firstlines_size =
      firstlines[loops].size();  // the size of one firstlines STR
  int characters_size = letters.size();

  for (int i = 0; i < characters_size; i++) {
    if (letters[i] == firstlines[loops][0])  // check if the first letter matches
                                             // with the first letter of the STR
    {
      findMatch(i, count, loops, firstlines_size, firstlines, letters);
    }
  }

  strCount.push_back(count);  // for each DNA strings in the firstlines
}

// TotalDna function will display the total DNA fonud
void TotalDna(ourvector<ourvector<char>> &firstlines,
              ourvector<int> &strCount) {
  int firstlines_size = firstlines.size();
  if (firstlines_size > 0) {
    cout << "Total DNA strings found in the database: " << endl;
    for (int i = 0; i < firstlines_size; i++) {
      int inside_size = firstlines[i].size();
      for (int j = 0; j < inside_size; j++) {
        cout << firstlines[i][j];
      }
      cout << ": " << strCount[i] << endl;
    }
  }
}

// find_total_dna function will find ALL dna strands
void find_total_dna(ourvector<ourvector<char>> &firstlines,
                    ourvector<DNA> &person, ourvector<char> &letter,
                    ourvector<int> &strCount) {
  int firstlines_size = firstlines.size();
  int loops = 0;
  // this will go for each vector in the 2d vector to compare it to the DNA
  // strand
  while (loops < firstlines_size) {
    countStr(loops, strCount, firstlines, letter);
    loops++;
  }
  TotalDna(firstlines, strCount);
}

// getUserCommand function will get the user's command
void getUserCommand(string &filename, ourvector<ourvector<char>> &firstlines,
                    ourvector<DNA> &person, ourvector<char> &letter,
                    ourvector<int> &strCount) {
  string command;
  cout << "Enter command or # to exit: ";
  cin >> command;  // user enters command
  while (command != "#") {
    if (command == "load_db") {
      cin >> filename;
      load_db(filename, firstlines,
              person);  // need to pass in the vectors to load the database
    } else if (command == "display") {
      display(firstlines, person, letter, strCount);
    }

    else if (command == "load_dna") {
      cin >> filename;
      load_dna(filename, letter, strCount);}
      else if (command == "process") {
      process(firstlines, person, letter, strCount);}
      else if (command == "search") {
      search(person, letter, strCount);}
      else if (command == "find_total_dna") {
      find_total_dna(firstlines, person, letter, strCount);}
    // user enters command again
    cout << "Enter command or # to exit: ";
    cin >> command;
  }
}

int main() {
  //TODO: Write your code here.  You should have LOTS of function
  // decomposition.

  cout << "Welcome to the DNA Profiling Application." << endl;

  // vectors:

  ourvector<ourvector<char>>
      firstlines;  // 2 dimensional array for the firstlines
  // create the vector for the names to be stored
  ourvector<DNA> person;  // name and numbers require the use of strings
  ourvector<char> letter;  // for the long DNA strings
  ourvector<int> strCount;  // count for each firstlines strands

  string filename;  // for the filename

  getUserCommand(filename, firstlines, person, letter,
                 strCount);  // get the user commands to run the program

  return 0;
}